{{/*------------------- Custom Validator -------------------------------------------------------------*/}}
{{- define "validate-custom-validator-config" }}
  {{- range .Values.routesConfig }}
  {{- if .filters }}
  
    {{/* Validate CustomReqHeaderEntryFilter */}}
    {{- if .filters.customReqHeaderEntryFilter }}
        {{- range .filters.customReqHeaderEntryFilter.headers }}
            {{- range .headersList }}
                {{- if or (not .defaultVal) (eq (toString .defaultVal) "null") }}
                  {{- fail (printf "defaultVal is null") }}
                {{- end }}
            {{- end }}
        {{- end }}
    {{- end }}

    {{/* Validate CustomReqHeaderExitFilter */}}
    {{- if .filters.customReqHeaderExitFilter }}
        {{- range .filters.customReqHeaderExitFilter.headers }}
            {{- range .headersList }}
                {{- if or (not .defaultVal) (eq (toString .defaultVal) "null") }}
                  {{- fail (printf "defaultVal is null") }}
                {{- end }}
            {{- end }}
        {{- end }}
    {{- end }}

    {{/* Validate CustomResHeaderEntryFilter */}}
    {{- if .filters.customResHeaderEntryFilter }}
        {{- range .filters.customResHeaderEntryFilter.headers }}
            {{- range .headersList }}
                {{- if or (not .defaultVal) (eq (toString .defaultVal) "null") }}
                  {{- fail (printf "defaultVal is null") }}
                {{- end }}
            {{- end }}
        {{- end }}
    {{- end }}

    {{/* Validate CustomResHeaderExitFilter */}}
    {{- if .filters.customResHeaderExitFilter }}
        {{- range .filters.customResHeaderExitFilter.headers }}
            {{- range .headersList }}
                {{- if or (not .defaultVal) (eq (toString .defaultVal) "null") }}
                  {{- fail (printf "defaultVal is null") }}
                {{- end }}
            {{- end }}
        {{- end }}
    {{- end }}

  {{- end }}
  {{- end }}
{{- end }}