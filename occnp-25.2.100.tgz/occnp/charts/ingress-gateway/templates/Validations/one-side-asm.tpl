{{- define "validate-one-side-asm" }}

{{/* To validate that the port value provided is between 0 and 65535 */}}
{{ include "validatePortRange" (list .Values.global.intraNFCommunicationPort "intraNFCommunicationPort") }}
{{ include "validatePortRange" (list .Values.ports.containerIntraNFCommPort "containerIntraNFCommPort") }}

{{/* To validate that the name given for port is not empty */}}
{{ include "validateNonEmptyString" (list .Values.global.intraNFComPortName "intraNFComPortName")}}
{{ include "validateNonEmptyString" (list .Values.ports.containerIntraNFCommPortName "containerIntraNFCommPortName")}}

{{/* To validate that flag value provided is boolean */}}
{{ include "validateBoolean" (list .Values.intraNfServiceMesh "intraNfServiceMesh")}}
{{ include "validateBoolean" (list .Values.serviceMeshCheck "serviceMeshCheck")}}

{{- end }}

{{- define "validatePortRange" }}
  {{- $port := index . 0 }}
  {{- $name := index . 1 }}
  {{- if not (regexMatch "^-?[0-9]+$" (toString $port)) }}
    {{- fail (printf "Invalid %s port: %v. Port must be an integer." $name $port) }}
  {{- else if or (gt (int $port) 65535) (lt (int $port) 0) }}
    {{- fail (printf "Invalid %s port: %v. Port must be between 0 and 65535." $name $port) }}
  {{- end }}
{{- end }}

{{- define "validateNonEmptyString" }}
  {{- $value := index . 0 }}
  {{- $name := index . 1 }}
  {{- if eq ($value | quote | trim) "" }}
    {{- fail (printf "Invalid %s: Cannot be empty." $name) }}
  {{- end }}
{{- end }}

{{- define "validateBoolean" }}
  {{- $value := index . 0 }}
  {{- $name := index . 1 }}
  {{- if not (kindIs "bool" $value) }}
    {{- fail (printf "Invalid %s: Must be a boolean." $name) }}
  {{- end }}
{{- end }}