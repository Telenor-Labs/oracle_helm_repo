# Copyright 2020 (C), Oracle and/or its affiliates. All rights reserved.

{{/* vim: set filetype=mustache: */}}

{{/*--------------------------------------Debug Tool Container---------------------------------------------------*/}}
{{- define "extraContainers" -}}
  {{- if (eq .Values.extraContainers "ENABLED") -}}
    {{- tpl ( .Values.global.extraContainersTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}}
    {{- if (eq .Values.global.extraContainers "ENABLED") -}}
      {{- tpl ( .Values.global.extraContainersTpl) . }}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*--------------------------------------Debug Tool Container Volume Mount---------------------------------------------------*/}}
{{- define "igw-extraContainersVolume" -}}
  {{- if (eq .Values.extraContainers "ENABLED") -}}
- name: debug-tools-dir
  emptyDir:
    medium: Memory
    sizeLimit: 4Gi
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}}
    {{- if (eq .Values.global.extraContainers "ENABLED") -}}
- name: debug-tools-dir
  emptyDir:
    medium: Memory
    sizeLimit: 4Gi
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*--------------------Expand the name of the chart.-------------------------------------------------------------*/}}
{{- define "chart.fullname" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Perf Info Service Name-------------------------------------------------------------*/}}
{{- define "service.perfInfoServiceFullName" -}}
{{- if .Values.global.perfInfoConfig.serviceName -}}
{{- $name := .Values.global.perfInfoConfig.serviceName -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- else -}}
{{- .Values.global.perfInfoConfig.host | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*--------------------Create chart name and version as used by the chart label.---------------------------------*/}}
{{- define "chart.fullnameandversion" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}


{{/*--------------------Common Service Account Name---------------------------------------------------------------*/}}
{{- define "ingressgateway.serviceaccount" -}}
{{- if $.Values.prefix -}}
{{- printf "%s-%s-%s" .Release.Name .Values.prefix "ingressgateway-serviceaccount" | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name "ingressgateway-serviceaccount" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*--------------------IGW Service Type---------------------------------------------------------------*/}}
{{- define "ingressgateway.serviceType" }}
  {{- .Values.global.type }}
{{- end }}

{{/*--------------------Common ROLE-------------------------------------------------------------------------------*/}}
{{- define "ingressgateway.role" -}}
{{- if $.Values.prefix -}}
{{- printf "%s-%s" .Release.Name .Values.prefix | trunc 63 | trimSuffix "-" -}}-ingressgateway-role
{{- else -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}-ingressgateway-role
{{- end -}}
{{- end -}}


{{/*--------------------Common ROLE BINDING----------------------------------------------------------------------*/}}
{{- define "ingressgateway.rolebinding" -}}
{{- if $.Values.prefix -}}
{{- printf "%s-%s" .Release.Name .Values.prefix | trunc 63 | trimSuffix "-" -}}-ingressgateway-rolebinding
{{- else -}}
{{ .Release.Name | trunc 63 | trimSuffix "-" -}}-ingressgateway-rolebinding
{{- end -}}
{{- end -}}

{{/*-------------------get prefix.-------------------------------------------------------------*/}}
{{- define "getprefix" -}}
{{  default "" .Values.global.k8sResource.container.prefix | lower }}
{{- end -}}

{{/*-------------------getsuffix.-------------------------------------------------------------*/}}
{{- define "getsuffix" -}}
{{  default "" .Values.global.k8sResource.container.suffix | lower }}
{{- end -}}

{{/*--------------------Expand the name of the container.-------------------------------------------------------------*/}}
{{- define "container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s" $prefix (include "chart.fullname" . ) $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Ephemeral Storage---------------------------------------------------------------*/}}
{{- define "ingress-gateway-ephemeral-storage-request" -}}
 {{- div (mul (add .Values.global.logStorage .Values.global.crictlStorage) 11) 10 -}}Mi
{{- end -}}

{{- define "ingress-gateway-ephemeral-storage-limit" -}}
 {{- .Values.global.ephemeralStorageLimit -}}Mi
{{- end -}}

{{/*--------------------TLSv1.3 support for Kube-Api-Server---------------------------------------------------------------*/}}
{{- define "validate-tlsv-support-for-k8s-config" -}}
  {{- if .Values.tlsVersionSupportForKubeApiServer.enabled }}
    {{- $validVersions := list "TLSv1.3" "TLSv1.2" }}
    {{- if not (has .Values.tlsVersionSupportForKubeApiServer.kubeApiServerTlsVersion $validVersions) }}
      {{- printf "false" -}}
    {{- else }}
      {{- $tlsSecrets := list }}
      {{- $mcSecrets := list }}
      {{- $ccaSecrets := list }}
      {{- $secrets := list }}
      {{- if .Values.initssl }}
        {{- $tlsSecrets = list .Values.service.ssl.privateKey.k8SecretName .Values.service.ssl.certificate.k8SecretName .Values.service.ssl.caBundle.k8SecretName .Values.service.ssl.keyStorePassword.k8SecretName .Values.service.ssl.trustStorePassword.k8SecretName | uniq }}
      {{- end }}
      {{- if  and .Values.messageCopy.enabled .Values.messageCopy.security.enabled }}
        {{- $mcSecrets = list .Values.service.ssl.trustStorePassword.k8SecretName .Values.messageCopy.security.saslConfiguration.password.k8SecretName | uniq }}
      {{- end }}
      {{- if and (.Values.ccaHeaderValidationConfigMode | eq "HELM") .Values.ccaHeaderValidation.enabled }}
        {{- $ccaSecrets = list .Values.ccaHeaderValidation.k8SecretName }}
      {{- end }}
      {{- $secrets = concat $tlsSecrets $mcSecrets $ccaSecrets }}
      {{- $secrets = $secrets | uniq }}
      {{- $featureSecrets := .Values.tlsVersionSupportForKubeApiServer.featureSecrets }}
      {{- range $secrets }}
        {{- if not (has . $featureSecrets) }}
          {{- printf "false" -}}
        {{- end }}
      {{- end }}
    {{- end}}
  {{- else }}
    {{- printf "true" -}}
  {{- end }}
{{- end -}}


{{/*--------------------Service Name-----------------------------------------------------------------------------*/}}
{{/***************************************************************************************************************
     NOTE: 1. Engineering Configuration:  Micro-Service routes (.Values.ingressgateway.routesConfig) must be updated
              if there is any change in service.fullname template.
   ***************************************************************************************************************/}}
{{- define "service.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- if $.Values.prefix -}}
{{- printf "%s-%s" .Release.Name .Values.prefix | trunc 63 | trimSuffix "-" -}}-{{- .Chart.Name }}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*--------------------Internal Service Name------------------------------------------------------------*/}}
{{- define "service.internalName" -}}
{{- printf "%s-intra-nf" (include "service.fullname" .) }}
{{- end -}}

{{/*--------------------Common Config server Service Name------------------------------------------------------------*/}}
{{- define "service.ConfigServerSvcFullname" -}}
{{- if .Values.commonCfgServer.configServerSvcName -}}
{{- $name := .Values.commonCfgServer.configServerSvcName -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- else -}}
{{- .Values.commonCfgServer.host | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*--------------------Coherence Service Name------------------------------------------------------------*/}}
{{- define "service.igw.CoherenceSvcFullname" -}}
{{- if $.Values.prefix -}}
{{- printf "%s-%s-%s" .Release.Name .Values.prefix "igw-cache" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name "igw-cache" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*--------------------Alternate route Service Name-------------------------------------------------------------*/}}
{{- define "service.alternateRouteSvcFullname" -}}
{{- if .Values.dnsSrv.alternateRouteSvcName -}}
{{- $name := .Values.dnsSrv.alternateRouteSvcName -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- else -}}
{{- .Values.dnsSrv.host | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}


{{/*--------------------Metric prefix for adding custom prefix to metric name------------------------------------------------------------*/}}
{{- define "metric.prefix" -}}
{{- if .Values.metricPrefix -}}
{{- .Values.metricPrefix -}}
{{- else if .Values.global.metricPrefix -}}
{{- .Values.global.metricPrefix -}}
{{- end -}}
{{- end -}}
{{/*--------------------Metric suffix for adding custom suffix to metric name------------------------------------------------------------*/}}
{{- define "metric.suffix" -}}
{{- if .Values.metricSuffix -}}
{{- .Values.metricSuffix -}}
{{- else if .Values.global.metricSuffix -}}
{{- .Values.global.metricSuffix -}}
{{- end -}}
{{- end -}}

{{/*-------------------- Persistent configuration --------------------------------------------------------------------*/}}
{{- define "defaultconfig-igw.labels" -}}
{{- $loggingJson := tpl ( .Files.Get "config/logging.json" ) . }}
logging:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "logging" .Values.nfSpecificConfig.featureList) ($loggingJson) }}
{{ $loggingJson | indent 2 }}
{{- else }}
  appLogLevel: {{ .Values.log.level.ingress }}
  packageLogLevel:
  - packageName: root
    logLevelForPackage: {{ .Values.log.level.root }}
  - packageName: oauth
    logLevelForPackage: {{ .Values.log.level.oauth }}
  logDiscarding:
    enabled: {{ .Values.log.discarding.enabled }}
    featureToThresholdMapping:
  {{- range .Values.log.discarding.featureToThresholdMapping }}
  {{- if .feature }}
    - feature: {{ .feature }}
  {{- end }}
  {{- if .thresholdFactor }}
      thresholdFactor: {{ .thresholdFactor }}
  {{- end }}
  {{- end }}
  additionalErrorLogging: {{ .Values.log.additionalErrorLogging }}
  logSubscriberInfo: {{ .Values.log.logSubscriberInfo }}
{{- end }}
{{- else }}
  appLogLevel: {{ .Values.log.level.ingress }}
  packageLogLevel:
  - packageName: root
    logLevelForPackage: {{ .Values.log.level.root }}
  - packageName: oauth
    logLevelForPackage: {{ .Values.log.level.oauth }}
  logDiscarding:
    enabled: {{ .Values.log.discarding.enabled }}
    featureToThresholdMapping:
  {{- range .Values.log.discarding.featureToThresholdMapping }}
  {{- if .feature }}
    - feature: {{ .feature }}
  {{- end }}
  {{- if .thresholdFactor }}
      thresholdFactor: {{ .thresholdFactor }}
  {{- end }}
  {{- end }}
  additionalErrorLogging: {{ .Values.log.additionalErrorLogging }}
  logSubscriberInfo: {{ .Values.log.logSubscriberInfo }}
{{- end }}
{{- $oauthValidatorConfigurationJson := tpl ( .Files.Get "config/oauthvalidatorconfiguration.json" ) . }}
oauthvalidatorconfiguration:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "oauthvalidatorconfiguration" .Values.nfSpecificConfig.featureList) ($oauthValidatorConfigurationJson) }}
{{ $oauthValidatorConfigurationJson | indent 2 }}
{{- else }}
  keyIdList: []
  instanceIdList: []
  oauthValidationMode: INSTANCEID_ONLY
{{- end }}
{{- else }}
  keyIdList: []
  instanceIdList: []
  oauthValidationMode: INSTANCEID_ONLY
{{- end }}
{{- $errorCodeProfilesJson := tpl ( .Files.Get "config/errorcodeprofiles.json" ) . }}
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.enabled) (has "errorcodeprofiles" .Values.nfSpecificConfig.featureList) ($errorCodeProfilesJson) }}
errorcodeprofiles:
{{ $errorCodeProfilesJson | indent 2 }}
{{- else if .Values.errorCodeProfiles }}
{{- $errorCodeProfilesLength:= len .Values.errorCodeProfiles }}
{{- if gt $errorCodeProfilesLength 0 }}
errorcodeprofiles:
{{- range .Values.errorCodeProfiles }}
  - name: {{ .name }}
    errorCode: {{ .errorCode }}
  {{- if .errorCause }}
    errorCause: {{ .errorCause }}
  {{- end }}
  {{- if .errorTitle }}
    errorTitle: {{ .errorTitle }}
  {{- end }}
  {{- if .errorDescription }}
    errorDescription: {{ .errorDescription }}
  {{- end }}
  {{- if .retryAfter }}
    retryAfter: {{ .retryAfter | quote }}
  {{- end }}
  {{- if .redirectUrl }}
    redirectUrl: {{ .redirectUrl | quote }}
  {{- end }}
{{- end }}
{{- else }}
errorcodeprofiles: []
{{- end }}
{{- else }}
errorcodeprofiles: []
{{- end }}
{{- end }}

{{- $configErrorCodesFlag := true }}
{{- if .Values.configurableErrorCodes }}
{{- range .Values.configurableErrorCodes.errorScenarios }}
{{- if .errorCode }}
{{- $configErrorCodesFlag = false }}
{{- end }}
{{- end }}
{{- end }}

{{- if $configErrorCodesFlag }}
{{- $configurableErrorCodesJson := tpl ( .Files.Get "config/configurableerrorcodes.json" ) . }}
configurableerrorcodes:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.configurableErrorCodes) (has "configurableerrorcodes" .Values.nfSpecificConfig.featureList) ($configurableErrorCodesJson) }}
{{ $configurableErrorCodesJson | indent 2 }}
{{- else }}
{{- if .Values.configurableErrorCodes }}
  enabled: {{ .Values.configurableErrorCodes.enabled }}
  errorScenarios:
{{- range .Values.configurableErrorCodes.errorScenarios }}
{{- if .exceptionType }}
  - exceptionType: {{ .exceptionType }}
{{- end }}
{{- if .errorProfileName }}
    errorProfileName: {{ .errorProfileName }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- else }}
{{- if .Values.configurableErrorCodes }}
  enabled: {{ .Values.configurableErrorCodes.enabled }}
  errorScenarios:
{{- range .Values.configurableErrorCodes }}
{{- if .exceptionType }}
  - exceptionType: {{ .exceptionType }}
{{- end }}
{{- if .errorProfileName }}
    errorProfileName: {{ .errorProfileName }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{- $healthCheckConfigJson := tpl ( .Files.Get "config/healthCheckConfigOptions.json" ) . }}
{{- if and (.Values.nfSpecificConfig) }}
{{- if and (.Values.nfSpecificConfig.enabled) (has "health-check-monitoring" .Values.nfSpecificConfig.featureList) ($healthCheckConfigJson) }}
healthCheckConfigOptions:
{{ $healthCheckConfigJson | indent 2 }}
{{- end }}
{{- end }}

{{- $ocDiscardPoliciesJson := tpl ( .Files.Get "config/ocdiscardpolicies.json" ) . }}
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.enabled) (has "ocdiscardpolicies" .Values.nfSpecificConfig.featureList) ($ocDiscardPoliciesJson) }}
ocdiscardpolicies:
{{ $ocDiscardPoliciesJson | indent 2 }}
{{- else }}
ocdiscardpolicies: []
{{- end }}
{{- else }}
ocdiscardpolicies: []
{{- end }}

{{- $controlledShutdownErrorMappingJson := tpl ( .Files.Get "config/controlledshutdownerrormapping.json" ) . }}
controlledshutdownerrormapping:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "Controlledshutdownerrormapping" .Values.nfSpecificConfig.featureList) ($controlledShutdownErrorMappingJson) }}
{{ $controlledShutdownErrorMappingJson | indent 2 }}
{{- else }}
  routeErrorProfileList: []
{{- end }}
{{- else }}
  routeErrorProfileList: []
{{- end }}

{{- $xfccHeaderValidationJson := tpl ( .Files.Get "config/xfccHeaderValidationJson.json" ) . }}
xfccheadervalidation:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "xfccHeaderValidation" .Values.nfSpecificConfig.featureList) ($xfccHeaderValidationJson) }}
{{ $xfccHeaderValidationJson | indent 2 }}
{{- else if ( eq (.Values.global.xfccHeaderValidationConfigMode) "REST" ) }}
  validation:
    enabled: false
    peerlist: []
    matchcerts: -1
    matchfield: "DNS"
    dnsresolutioninterval: 300000
  extract:
    enabled: false
    certextractindex: 0
    extractfield: "DNS"
    extractindex: 0
{{- else }}
  validation:
    enabled: false
    peerlist: []
    matchcerts: -1
    matchfield: "DNS"
    dnsresolutioninterval: 300000
  extract:
    enabled: false
    certextractindex: 0
    extractfield: "DNS"
    extractindex: 0
{{- end }}
{{- end }}

{{- $ccaheaderJson := tpl ( .Files.Get "config/ccaheaderJson" ) . }}
ccaheader:
{{- if and (.Values.nfSpecificConfig) (.Values.nfSpecificConfig.featureList) (has "ccaheader" .Values.nfSpecificConfig.featureList) ($ccaheaderJson) }}
{{ $ccaheaderJson | indent 2 }}
{{- else }}
{{- if  .Values.ccaHeaderValidation }}
  enabled: {{ .Values.ccaHeaderValidation.enabled }}
  minExpiryTime: {{ .Values.ccaHeaderValidation.minExpiryTime }}
  maxTokenAge: {{ .Values.ccaHeaderValidation.maxTokenAge }}
  role: {{ .Values.ccaHeaderValidation.role }}
  subKey: {{ .Values.ccaHeaderValidation.subKey }}
  validationRule: {{ .Values.ccaHeaderValidation.validationRule }}
  k8SecretName: {{ .Values.ccaHeaderValidation.k8SecretName }}
  k8NameSpace: {{ .Values.ccaHeaderValidation.k8NameSpace }}
  fileName: {{ .Values.ccaHeaderValidation.fileName }}
{{- else }}
  enabled: false
  minExpiryTime: 0
  maxTokenAge: 0
  role: "NRF"
  subKey: "subjectAltName"
  validationRule: "strict"
  k8SecretName: "ocegress-secret"
  k8NameSpace: "ocegress"
  fileName: "caroot.cer"
{{- end }}
{{- end }}

{{- $copyHeaderJson := tpl ( .Files.Get "config/copyHeaderJson" ) . }}
copyHeaderOnGatewayError:
{{- if and (.Values.nfSpecificConfig) (.Values.nfSpecificConfig.featureList) (has "copyHeaderOnGatewayError" .Values.nfSpecificConfig.featureList) ($copyHeaderJson) }}
{{ $copyHeaderJson | indent 2 }}
{{- else }}
{{- if  ( eq (.Values.copyHeaderConfigMode) "REST" ) }}
  enabled: {{ .Values.copyHeaderOnGatewayError.enabled }}
  requestToResponse:
    requestHeaderNames:
    {{- range .Values.copyHeaderOnGatewayError.requestToResponse.requestHeaderNames }}
    - {{ . }}
    {{- end }}
 {{- else }}
  enabled: false
  requestToResponse:
   requestHeaderNames:
    - defaultHeader
{{- end }}
{{- end }}

{{- $applicationParamsJson := tpl ( .Files.Get "config/applicationparams.json" ) . }}
applicationparams:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "applicationparams" .Values.nfSpecificConfig.featureList) ($applicationParamsJson) }}
{{ $applicationParamsJson | indent 2 }}
{{- else if .Values.defaultConfig.controlledShutdown.operationalState }}
  operationalState: {{ .Values.defaultConfig.controlledShutdown.operationalState }}
{{- else }}
  operationalState: NORMAL
{{- end }}
{{- else if .Values.defaultConfig.controlledShutdown.operationalState }}
  operationalState: {{ .Values.defaultConfig.controlledShutdown.operationalState }}
{{- else }}
  operationalState: NORMAL
{{- end }}

{{- $routesConfigurationJson := tpl ( .Files.Get "config/routesconfiguration.json" ) . }}
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.enabled) (has "routesconfiguration" .Values.nfSpecificConfig.featureList) ($routesConfigurationJson) }}
routesconfiguration:
{{ $routesConfigurationJson | indent 2 }}
{{- else if and ( eq (.Values.routeConfigMode) "REST" ) (.Values.convertHelmRoutesToREST)  (.Values.routesConfig)}}
{{- $routesConfigLength:= len .Values.routesConfig }}
{{- if gt $routesConfigLength 0 }}
routesconfiguration:
{{- range .Values.routesConfig }}
  - id: {{ .id }}
    uri: {{ tpl ( .uri ) $ }}
    {{- if .order }}
    order: {{ .order }}
    {{- end}}
    predicates:
      - name: Path
        args:
          pattern: {{ .path }}
        {{- if .method }}
      - name: Method
        args:

          methods: {{ .method }}
        {{- end}}
        {{- if .readBodyForLog }}
      - name: ReadBodyForLog
        args:
          enable: {{ .readBodyForLog | quote }}
        {{- end}}
  {{- if .metadata }}
    metadata:
    {{- if .metadata.configurableErrorCodes }}
        - configurableErrorCodes:
            enabled: {{ .metadata.configurableErrorCodes.enabled }}
            {{- if .metadata.configurableErrorCodes.errorScenarios }}
            errorScenarios:
              {{- range .metadata.configurableErrorCodes.errorScenarios }}
              - exceptionType: {{ .exceptionType | quote }}
                errorProfileName: {{ .errorProfileName | quote }}
              {{- end }}
            {{- end }}
    {{- end }}
    {{- if .metadata.requestTimeout }}
        - requestTimeout: {{ .metadata.requestTimeout }}
    {{- end }}
    {{- if .metadata.requiredTime }}
        - requiredTime: {{ .metadata.requiredTime }}
    {{- end }}
    {{- if .metadata.xfccHeaderValidation }}
        - xfccHeaderValidation:
            validationEnabled: {{ .metadata.xfccHeaderValidation.validationEnabled }}
    {{- end }}
    {{- if .metadata.ccaHeaderValidation }}
        - ccaHeaderValidation:
            enabled: {{ .metadata.ccaHeaderValidation.enabled }}
    {{- end }}
    {{- if .metadata.oauthValidator }}
        - oauthValidator:
            enabled: {{ .metadata.oauthValidator.enabled }}
    {{- end }}
    {{- if .metadata.svcName }}
        - svcName: {{ .metadata.svcName }}
    {{- end }}
    {{- if .metadata.serverHeaderDetails }}
        - serverHeaderDetails:
            enabled: {{ .metadata.serverHeaderDetails.enabled }}
            {{- if .metadata.serverHeaderDetails.errorCodeSeriesId }}
            errorCodeSeriesId: {{ .metadata.serverHeaderDetails.errorCodeSeriesId }}
            {{- end }}
    {{- end }}
  {{- end }}
  {{- if .filters }}
    filters:
    {{- if .filters.invalidRouteFilter }}
      - name: InvalidRouteFilter
        args:
        {{- range .filters.invalidRouteFilter }}
          errorCodeOnInvalidRoute: {{ .errorCodeOnInvalidRoute | default 503 | quote }}
          errorCauseOnInvalidRoute: {{ .errorCauseOnInvalidRoute | default "" | quote }}
          errorTitleOnInvalidRoute: {{ .errorTitleOnInvalidRoute | default "" | quote }}
          errorDescriptionOnInvalidRoute: {{ .errorDescriptionOnInvalidRoute | default "" | quote }}
          redirectUrl: {{ .redirectUrl | default "" | quote }}
        {{- end }}
    {{- end }}
    {{- if .filters.controlledShutdownFilter }}
      - name: ControlledShutdownFilter
        args:
          applicableShutdownStates:
          {{- range .filters.controlledShutdownFilter.applicableShutdownStates }}
          - {{ . }}
          {{- end }}
          {{- $unsupportedOperations := .filters.controlledShutdownFilter.unsupportedOperations | default list }}
          {{- if gt (len $unsupportedOperations) 0 }}
          unsupportedOperations:
          {{- range $unsupportedOperations }}
          - {{ . }}
          {{- end }}
          {{- end }}
    {{- end }}
    {{- if .filters.customReqHeaderEntryFilter }}
      - name: CustomReqHeaderEntryFilter
        args:
             {{- if .filters.customReqHeaderEntryFilter.headers }}
             headers:
                  {{- range .filters.customReqHeaderEntryFilter.headers }}
                  - methods:
                      {{- range .methods }}
                      - {{.}}
                      {{- end }}
                    headersList:
                      {{- range .headersList }}
                      - headerName: {{ .headerName }}
                        defaultVal: {{ .defaultVal }}
                        source: {{ .source }}
                        sourceHeader: {{ .sourceHeader }}
                        override: {{ default false .override }}
                      {{- end }}
                    {{- end }}
             {{- end }}
    {{- end }}
    {{- if .filters.customReqHeaderExitFilter }}
      - name: CustomReqHeaderExitFilter
        args:
             {{- if .filters.customReqHeaderExitFilter.headers }}
             headers:
                  {{- range .filters.customReqHeaderExitFilter.headers }}
                  - methods:
                      {{- range .methods }}
                      - {{.}}
                      {{- end }}
                    headersList:
                      {{- range .headersList }}
                      - headerName: {{ .headerName }}
                        defaultVal: {{ .defaultVal }}
                        source: {{ .source }}
                        sourceHeader: {{ .sourceHeader }}
                        override: {{ default false .override }}
                      {{- end }}
                    {{- end }}
             {{- end }}
    {{- end }}
    {{- if .filters.customResHeaderEntryFilter }}
      - name: CustomResHeaderEntryFilter
        args:
             {{- if .filters.customResHeaderEntryFilter.headers }}
             headers:
                  {{- range .filters.customResHeaderEntryFilter.headers }}
                  - methods:
                      {{- range .methods }}
                      - {{.}}
                      {{- end }}
                    headersList:
                      {{- range .headersList }}
                      - headerName: {{ .headerName }}
                        defaultVal: {{ .defaultVal }}
                        source: {{ .source }}
                        sourceHeader: {{ .sourceHeader }}
                        override: {{ default false .override }}
                      {{- end }}
                 {{- end }}
             {{- end }}
    {{- end }}
    {{- if .filters.customResHeaderExitFilter }}
      - name: CustomResHeaderExitFilter
        args:
             {{- if .filters.customResHeaderExitFilter.headers }}
             headers:
                 {{- range .filters.customResHeaderExitFilter.headers }}
                 - methods:
                     {{- range .methods }}
                     - {{ . }}
                     {{- end }}
                   headersList:
                     {{- range .headersList }}
                     - headerName: {{ .headerName }}
                       defaultVal: {{ .defaultVal }}
                       source: {{ .source }}
                       sourceHeader: {{ .sourceHeader }}
                       override: {{ default false .override }}
                     {{- end }}
                 {{- end }}
             {{- end }}
    {{- end }}
    {{- if .filters.subLog }}
      - name: SubLog
        args:
          pattern: {{ .filters.subLog }}
    {{- end }}
    {{- if .removeResponseHeader }}
      - name: RemoveResponseHeader
        args:
      {{- range .removeResponseHeader }}
          - name: {{ .name }}
      {{- end }}
    {{- end }}
    {{- if .removeRequestHeader }}
      - name: RemoveRequestHeader
        args:
      {{- range .removeRequestHeader }}
          - name: {{ .name }}
      {{- end }}
    {{- end }}
    {{- if .filters.rewritePath }}
      - name: RewritePath
        args:
          regexp: {{ trim (split "," .filters.rewritePath)._0 }}
          replacement: {{ trim (split "," .filters.rewritePath)._1 }}
    {{- end }}
    {{- if .filters.prefixPath }}
      - name: PrefixPath
        args:
          prefix: {{ .filters.prefixPath }}
    {{- end }}
    {{- if .filters.addRequestHeader }}
      - name: AddRequestHeader
        args:
      {{- range .filters.addRequestHeader }}
          - name: {{ .name }}
            value: {{ .value }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
{{- else }}
routesconfiguration: []
{{- end }}
{{- else }}
routesconfiguration: []
{{- end }}
{{- end }}

{{/*------------------- Message Copy -------------------------------------------------------------*/}}
{{ include "validate-message-copy-config" . -}}

{{/*----------------------------------Policer Configuration Start------------------------------------*/}}
{{ include "pod-protection-by-rate-limiting" . -}}
{{ include "congestion-config" . -}}
{{/*-----------------------------------Policer Configuration End-------------------------------------*/}}

{{- $ocPolicyMappingJson := tpl ( .Files.Get "config/ocpolicymapping.json" ) . }}
ocpolicymapping:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "ocpolicymapping" .Values.nfSpecificConfig.featureList) ($ocPolicyMappingJson) }}
{{ $ocPolicyMappingJson | indent 2 }}
{{- else }}
  enabled: false
  samplingPeriod: {{ .Values.defaultConfig.overloadControl.samplingPeriod }}
  mappings:
{{- end }}
{{- else }}
  enabled: false
  samplingPeriod: {{ .Values.defaultConfig.overloadControl.samplingPeriod }}
  mappings:
{{- end }}
{{- $routeLevelRateLimitingJson := tpl ( .Files.Get "config/routelevelratelimiting.json" ) . }}
routelevelratelimiting:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "routelevelratelimiting" .Values.nfSpecificConfig.featureList) ($routeLevelRateLimitingJson) }}
{{ $routeLevelRateLimitingJson | indent 2 }}
{{- else }}
  enabled: false
  samplingPeriod: {{ .Values.defaultConfig.rateLimiting.samplingPeriod }}
  rateLimitPolicies:
{{- end }}
{{- else }}
  enabled: false
  samplingPeriod: {{ .Values.defaultConfig.rateLimiting.samplingPeriod }}
  rateLimitPolicies:
{{- end }}
{{- $serverHeaderDetailsJson := tpl ( .Files.Get "config/serverheaderdetails.json" ) . }}
serverheaderdetails:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.enabled) (.Values.nfSpecificConfig.featureList) (has "serverheaderdetails" .Values.nfSpecificConfig.featureList) ( eq (.Values.serverHeaderConfigMode) "REST" ) ($serverHeaderDetailsJson) }}
{{ $serverHeaderDetailsJson | indent 2 }}
{{- else if and (.Values.nfSpecificConfig.enabled) (.Values.nfSpecificConfig.featureList) (has "serverheaderdetails" .Values.nfSpecificConfig.featureList) ( eq (.Values.serverHeaderConfigMode) "REST" ) }}
 enabled: false
 configuration:
   nfType: ""
{{- else if and ( eq (.Values.serverHeaderConfigMode) "REST" ) (.Values.serverHeaderDetails) }}
  enabled: {{ .Values.serverHeaderDetails.enabled }}
  {{- if .Values.serverHeaderDetails.errorCodeSeriesId }}
  errorCodeSeriesId: {{ .Values.serverHeaderDetails.errorCodeSeriesId }}
  {{- end }}
  configuration:
    {{- if .Values.serverHeaderDetails.configuration.nfType }}
    nfType: {{ .Values.serverHeaderDetails.configuration.nfType }}
    {{- end }}
    {{- if .Values.serverHeaderDetails.configuration.nfInstanceId }}
    nfInstanceId: {{ .Values.serverHeaderDetails.configuration.nfInstanceId }}
    {{- end }}
{{- else }}
  enabled: false
  configuration:
    nfType: ""
{{- end }}
{{- else }}
  enabled: false
  configuration:
    nfType: ""
{{- end }}
{{- $messageLoggingJson := tpl ( .Files.Get "config/messagelogging.json" ) . }}
messagelogging:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "messagelogging" .Values.nfSpecificConfig.featureList) ($messageLoggingJson) }}
{{ $messageLoggingJson | indent 2 }}
{{- else }}
  enabled: false
{{- end }}
{{- else }}
  enabled: false
{{- end }}
{{- $errorCodeSeriesListJson := tpl ( .Files.Get "config/errorcodeserieslist.json" ) . }}
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.enabled) (has "errorcodeserieslist" .Values.nfSpecificConfig.featureList) ($errorCodeSeriesListJson) }}
errorcodeserieslist:
{{ $errorCodeSeriesListJson | indent 2 }}
{{- else if .Values.errorCodeSeriesList }}
{{- $errorCodeSeriesLength:= len .Values.errorCodeSeriesList }}
{{- if gt $errorCodeSeriesLength 0 }}
errorcodeserieslist:
  {{- range .Values.errorCodeSeriesList }}
  - id: {{ .id }}
    errorCodeSeries:
    {{- range .errorCodeSeries }}
    - errorSet: {{ .errorSet }}
      errorCodes:
      {{- range .errorCodes }}
      - {{.}}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- else }}
  errorcodeserieslist:[]
  {{- end }}
{{- else }}
errorcodeserieslist:[]
{{- end }}
{{- end }}
{{- $trafficRejectModeJson := tpl ( .Files.Get "config/trafficrejectmode.json" ) . }}
trafficrejectmode:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "trafficrejectmode" .Values.nfSpecificConfig.featureList) ($trafficRejectModeJson) }}
{{ $trafficRejectModeJson | indent 2 }}
{{- else }}
  enabled: false
{{- end }}
{{- else }}
  enabled: false
{{- end }}
{{- $podProtectionJson := tpl ( .Files.Get "config/podprotection.json" ) . }}
podprotection:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "podprotection" .Values.nfSpecificConfig.featureList) ($podProtectionJson) }}
{{ $podProtectionJson | indent 2 }}
{{- else if and (.Values.nfSpecificConfig.enabled) (.Values.podProtection) }}
  enabled: {{ .Values.podProtection.enabled }}
  monitoringInterval: {{ .Values.podProtection.monitoringInterval }}
  congestionControl:
    enabled: {{ .Values.podProtection.congestionControl.enabled }}
    stateChangeSampleCount: {{ .Values.podProtection.congestionControl.stateChangeSampleCount }}
    actionSamplingPeriod: {{ .Values.podProtection.congestionControl.actionSamplingPeriod }}
    states:
     {{- range .Values.podProtection.congestionControl.states }}
     - name: {{ .name }}
       weight: {{ .weight }}
       {{- if  .resourceThreshold }}
       resourceThreshold:
         {{- if .resourceThreshold.cpu }}
         cpu: {{ .resourceThreshold.cpu }}
         {{- end }}
         {{- if .resourceThreshold.memory }}
         memory: {{ .resourceThreshold.memory }}
         {{- end }}
         {{- if .resourceThreshold.pendingMessage }}
         pendingMessage: {{ .resourceThreshold.pendingMessage }}
         {{- end }}
       {{- end}}
       entryAction:
       {{- range .entryAction }}
         - action: {{ .action }}
           args:
           {{- range $key, $value := .args }}
             {{ $key }}: {{ $value }}
           {{- end}}
       {{- end }}
     {{- end }}
{{- else }}
  enabled: false
{{- end }}
{{- else }}
  enabled: false
{{- end }}
{{- $readinessConfigJson := tpl ( .Files.Get "config/readinessconfig.json" ) . }}
readinessconfig:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.enabled) (.Values.readinessConfig) }}
  {{- if eq (toString .Values.readinessCheckEnabled) "true" }}
  serviceProfiles:
  {{- range .Values.readinessConfig.serviceProfiles }}
  - id: {{ .id | quote }}
    url: {{ .url | quote }}
    responseCode: {{ .responseCode | quote }}
    responseBody: {{ .responseBody | quote }}
    onExceptionUsePreviousState: {{ .onExceptionUsePreviousState }}
    initialState: {{ .initialState | quote }}
    {{- if .requestTimeout }}
    requestTimeout: {{ .requestTimeout | quote }}
    {{- end}}
  {{- end }}
  {{- else }}
  serviceProfiles:
  {{- end }}
{{- else if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "readinessconfig" .Values.nfSpecificConfig.featureList) ($readinessConfigJson) }}
{{ $readinessConfigJson | indent 2 }}
{{- else }}
  serviceProfiles:
{{- end }}
{{- else }}
  serviceProfiles:
{{- end }}
{{- else }}
  serviceProfiles:
{{- end }}
{{- $userAgentHeaderValidation := tpl ( .Files.Get "config/useragentheadervalidation.json" ) . }}
useragentheadervalidation:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.enabled) (.Values.nfSpecificConfig.featureList) (has "useragentheadervalidation" .Values.nfSpecificConfig.featureList) ( eq (.Values.userAgentHeaderValidationConfigMode) "REST" ) ($userAgentHeaderValidation) }}
{{ $userAgentHeaderValidation | indent 2 }}
{{- else if  eq (.Values.userAgentHeaderValidationConfigMode) "REST"  }}
  enabled: {{ .Values.userAgentHeaderValidation.enabled }}
  validationType: {{ .Values.userAgentHeaderValidation.validationType }}
{{- else }}
  enabled: false
  validationType: strict
{{ end }}
{{- else }}
{{- if  eq (.Values.userAgentHeaderValidationConfigMode) "REST"  }}
  enabled: {{ .Values.userAgentHeaderValidation.enabled }}
  validationType: {{ .Values.userAgentHeaderValidation.validationType }}
{{- else }}
  enabled: false
  validationType: strict
{{ end }}
{{- end }}
{{- end }}
{{/*--------------------Hook ConfigMap Name----------------------------------------------------------------------------*/}}
{{- define "hook-configmap.igw.fullname" -}}
{{- if $.Values.prefix -}}
{{- printf "%s-%s" .Release.Name .Values.prefix | trunc 63 | trimSuffix "-" -}}-hook-configmap-igw
{{- else -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}-hook-configmap-igw
{{- end -}}
{{- end -}}


{{/*--------------------Deployment Name---------------------------------------------------------------------------*/}}
{{- define "deployment.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- if $.Values.prefix -}}
{{- printf "%s-%s" .Release.Name .Values.prefix | trunc 63 | trimSuffix "-" -}}-{{- .Chart.Name }}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}


{{/*--------------------ConfigMap Name----------------------------------------------------------------------------*/}}
{{- define "configmap.fullname" -}}
{{- if $.Values.prefix -}}
{{- printf "%s-%s" .Release.Name .Values.prefix | trunc 63 | trimSuffix "-" -}}-{{- .Chart.Name }}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}


{{/*--------------------Horizontal Pod Autoscalar Name------------------------------------------------------------*/}}
{{- define "hpautoscalar.fullname" -}}
{{- if $.Values.prefix -}}
{{- printf "%s-%s" .Release.Name .Values.prefix | trunc 63 | trimSuffix "-" -}}-{{- .Chart.Name }}
{{- else -}}
{{ .Release.Name | trunc 63 | trimSuffix "-" -}}-{{- .Chart.Name }}
{{- end -}}
{{- end -}}

{{/*-------------------- Job Name for Pre-Install .--------------------------------*/}}
{{- define "pre-install-job.fullname" -}}
{{- printf "%s-%s" (include "service.fullname" .) "pre-install" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the pre-install container.--------------------------------*/}}
{{- define "pre-install-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service.fullname" .) "pre-install" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Pre-Upgrade .--------------------------------*/}}
{{- define "pre-upgrade-job.fullname" -}}
{{- printf "%s-%s" (include "service.fullname" .) "pre-upgrade" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Pre-Upgrade-oAuth-Validator .--------------------------------*/}}
{{- define "pre-upgrade-oauth-validator-job.fullname" -}}
{{- printf "%s-%s" (include "service.fullname" .) "pre-upgrade" | trunc 47 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the pre-upgrade container.--------------------------------*/}}
{{- define "pre-upgrade-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service.fullname" .) "pre-upgrade" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Pre-Rollback .--------------------------------*/}}
{{- define "pre-rollback-job.fullname" -}}
{{- printf "%s-%s" (include "service.fullname" .) "pre-rollback" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the pre-rollback container.--------------------------------*/}}
{{- define "pre-rollback-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service.fullname" .) "pre-rollback" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Pre-Delete .--------------------------------*/}}
{{- define "pre-delete-job.fullname" -}}
{{- printf "%s-%s" (include "service.fullname" .) "pre-delete" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the pre-delete container.--------------------------------*/}}
{{- define "pre-delete-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service.fullname" .) "pre-delete" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Post-Upgrade .--------------------------------*/}}
{{- define "post-upgrade-job.fullname" -}}
{{- printf "%s-%s" (include "service.fullname" .) "post-upgrade" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the post-upgrade container.--------------------------------*/}}
{{- define "post-upgrade-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service.fullname" .) "post-upgrade" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Post-Rollback .--------------------------------*/}}
{{- define "post-rollback-job.fullname" -}}
{{- printf "%s-%s" (include "service.fullname" .) "post-rollbck" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the post-rollback container.--------------------------------*/}}
{{- define "post-rollback-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service.fullname" .) "post-rollback" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}


{{/*--------------------Engineering Labels common for all microservices--------------------------------------------*/}}
{{- define "engineering.labels" -}}
app.kubernetes.io/name: {{ template "chart.fullname" . }}
helm.sh/chart: {{ template "chart.fullnameandversion" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
app.kubernetes.io/part-of: ocingress-gateway
app.kubernetes.io/vendor: {{ .Values.global.vendor }}
app.kubernetes.io/mktgVersion: {{ .Chart.AppVersion }}
app.kubernetes.io/engVersion: {{ .Chart.Version }}
app.kubernetes.io/application: {{ .Values.global.app_name }}
app.kubernetes.io/microservice: ocingress-gateway
app.kubernetes.io/component: ingress-front-end
{{- end -}}

{{- define "engineering.hooks.labels" -}}
app.kubernetes.io/name: {{ template "chart.fullname" . }}
helm.sh/chart: {{ template "chart.fullnameandversion" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
app.kubernetes.io/part-of: ocingress-gateway
app.kubernetes.io/vendor: {{ .Values.global.vendor }}
app.kubernetes.io/mktgVersion: {{ .Chart.AppVersion }}
app.kubernetes.io/engVersion: {{ .Chart.Version }}
app.kubernetes.io/application: {{ .Values.global.app_name }}
app.kubernetes.io/microservice: ocingress-gateway
app.kubernetes.io/component: internal
{{- end -}}

{{/*--------------------Engineering Annotations common for all microservices---------------------------------------*/}}
{{- define "engineering.annotations" -}}
{{- end -}}

{{/*--------------------Service mesh check flag------------------------------------------------*/}}
{{- define "servicemesh.check" -}}
{{ .Values.serviceMeshCheck | quote}}
{{- end -}}

{{/*--------------------Intra NF Service mesh check flag------------------------------------------------*/}}
{{- define "intra.nf.service.mesh" -}}
{{ .Values.intraNfServiceMesh | quote}}
{{- end -}}

{{/*--------------------Exclude inbound ports check------------------------------------------------*/}}
{{- define "exclude.inbound.ports" -}}
{{- $additionalPorts := list 7 53 }}
{{- $baseExcludedInboundPorts := list .Values.coherence.messagingPort1 .Values.coherence.messagingPort2 .Values.ports.actuatorPort .Values.ports.containerIntraNFCommPort }}
{{- $excludedInboundPorts := $baseExcludedInboundPorts }}
{{- if and $.Values.serviceMeshCheck (not $.Values.intraNfServiceMesh) }}
{{- $excludedInboundPorts = concat $baseExcludedInboundPorts $additionalPorts }}
{{- end -}}
{{- join "," $excludedInboundPorts }}
{{- end -}}

{{/*--------------------Exclude outbound ports check------------------------------------------------*/}}
{{- define "exclude.outbound.ports" -}}
{{- $additionalPorts := list 7 53 }}
{{- $baseExcludedOutboundPorts := list .Values.coherence.messagingPort1 .Values.coherence.messagingPort2 .Values.ports.actuatorPort }}
{{- $excludedOutboundPorts := $baseExcludedOutboundPorts }}
{{- if and $.Values.serviceMeshCheck (not $.Values.intraNfServiceMesh) }}
{{- $excludedOutboundPorts = concat $baseExcludedOutboundPorts $additionalPorts }}
{{- end -}}
{{- join "," $excludedOutboundPorts }}
{{- end -}}

{{/*--------------------Validate Service Discovery Configuration------------------------------------------------*/}}
{{ include "service.discovery.mechanism" . -}}

{{/*--------------------istioProxy ready URL------------------------------------------------*/}}
{{- define "istioproxy.ready.url" -}}
{{ .Values.istioSidecarReadyUrl | quote}}
{{- end -}}

{{/*--------------------istioProxy quit URL------------------------------------------------*/}}
{{- define "istioproxy.quit.url" -}}
{{ .Values.istioSidecarQuitUrl | quote}}
{{- end -}}

{{/*--------------------Kube Api Server TLS version------------------------------------------------*/}}
{{- define "kube.api.server.tlsversion" -}}
  {{- if (.Values.tlsVersionSupportForKubeApiServer) }}
    {{- if (.Values.tlsVersionSupportForKubeApiServer.enabled) }}
      {{- printf .Values.tlsVersionSupportForKubeApiServer.kubeApiServerTlsVersion -}}
    {{- else }}
      {{- printf "TLSv1.2" }}
    {{- end }}
  {{- else }}
    {{- printf "TLSv1.2" }}
  {{- end }}
{{- end -}}

{{/*##################################################################################################################
############################    CustomExtension LABELS section START       ###########################################*/}}

{{/*--------------------CustomExtension labels for lb services-----------------------------------------------------------*/}}
{{- define "custom.extensions.labels.lbServices" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- $global_lbServices_labels := .Values.global.customExtension.lbServices.labels -}}
  {{- $service_specific_labels := .Values.service.customExtension.labels -}}
  {{- $result := dict }}
  {{- $result := merge $result $service_specific_labels }}
  {{- $result := merge $result $global_lbServices_labels }}
  {{- $result := merge $result $global_allResources_labels }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}


{{/*--------------------CustomExtension labels for non lb services-----------------------------------------------------------*/}}
{{- define "custom.extensions.labels.nonlbServices" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- $global_nonlbServices_labels := .Values.global.customExtension.nonlbServices.labels -}}
  {{- $service_specific_labels := .Values.service.customExtension.labels -}}
  {{- $result := dict }}
  {{- $result := merge $result $service_specific_labels }}
  {{- $result := merge $result $global_nonlbServices_labels }}
  {{- $result := merge $result $global_allResources_labels }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*--------------------CustomExtension labels for non lb cache services----------------------------------------------------------*/}}
{{- define "custom.extensions.labels.nonlbCacheServices" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- $global_nonlbServices_labels := .Values.global.customExtension.nonlbServices.labels -}}
  {{- $result := dict }}
  {{- $result := merge $result $global_nonlbServices_labels }}
  {{- $result := merge $result $global_allResources_labels }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*--------------------CustomExtension labels for lb deployments-----------------------------------------------------------*/}}
{{- define "custom.extensions.labels.lbDeployments" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- $global_lbDeployment_labels := .Values.global.customExtension.lbDeployments.labels -}}
  {{- $deployment_specific_labels := .Values.deployment.customExtension.labels -}}
  {{- $result := dict }}
  {{- $result := merge $result $deployment_specific_labels }}
  {{- $result := merge $result $global_lbDeployment_labels }}
  {{- $result := merge $result $global_allResources_labels }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}


{{/*--------------------CustomExtension labels for non lb deployments-----------------------------------------------------------*/}}
{{- define "custom.extensions.labels.nonlbDeployments" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- $global_nonlbDeployment_labels := .Values.global.customExtension.nonlbDeployments.labels -}}
  {{- $deployment_specific_labels := .Values.deployment.customExtension.labels -}}
  {{- $result := dict }}
  {{- $result := merge $result $deployment_specific_labels }}
  {{- $result := merge $result $global_nonlbDeployment_labels }}
  {{- $result := merge $result $global_allResources_labels }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*--------------------CustomExtension labels for all kubernetes resources-----------------------------------------------------------*/}}
{{- define "custom.extensions.labels.allResources" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- range $key, $value := $global_allResources_labels }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*##############################           CustomExtension LABELS section END    ################################################
###################################################################################################################################*/}}


{{/*###############################################################################################################################
############################    CustomExtension ANNOTATIONS section START        ##################################################*/}}

{{/*--------------------CustomExtension annotations for lb services-----------------------------------------------------------*/}}
{{- define "custom.extensions.annotations.lbServices" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- $global_lbServices_annotations := .Values.global.customExtension.lbServices.annotations -}}
  {{- $service_specific_annotations := .Values.service.customExtension.annotations -}}
  {{- $result := dict }}
  {{- $result := merge $result $service_specific_annotations }}
  {{- $result := merge $result $global_lbServices_annotations }}
  {{- $result := merge $result $global_allResources_annotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}


{{/*--------------------CustomExtension annotations for non lb services-----------------------------------------------------------*/}}
{{- define "custom.extensions.annotations.nonlbServices" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- $global_nonlbServices_annotations := .Values.global.customExtension.nonlbServices.annotations -}}
  {{- $service_specific_annotations := .Values.service.customExtension.annotations -}}
  {{- $result := dict }}
  {{- $result := merge $result $service_specific_annotations }}
  {{- $result := merge $result $global_nonlbServices_annotations }}
  {{- $result := merge $result $global_allResources_annotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*--------------------CustomExtension annotations for non lb cache services-----------------------------------------------------*/}}
{{- define "custom.extensions.annotations.nonlbCacheServices" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- $global_nonlbServices_annotations := .Values.global.customExtension.nonlbServices.annotations -}}
  {{- $result := dict }}
  {{- $result := merge $result $global_nonlbServices_annotations }}
  {{- $result := merge $result $global_allResources_annotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*--------------------CustomExtension annotations for lb deployments-----------------------------------------------------------*/}}
{{- define "custom.extensions.annotations.lbDeployments" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- $global_lbDeployment_annotations := .Values.global.customExtension.lbDeployments.annotations -}}
  {{- $deployment_specific_annotations := .Values.deployment.customExtension.annotations -}}
  {{- $result := dict }}
  {{- $result := merge $result $deployment_specific_annotations }}
  {{- $result := merge $result $global_lbDeployment_annotations }}
  {{- $result := merge $result $global_allResources_annotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*--------------------CustomExtension annotations for non lb deployments-----------------------------------------------------------*/}}
{{- define "custom.extensions.annotations.nonlbDeployments" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- $global_nonlbDeployment_annotations := .Values.global.customExtension.nonlbDeployments.annotations -}}
  {{- $deployment_specific_annotations := .Values.deployment.customExtension.annotations -}}
  {{- $result := dict }}
  {{- $result := merge $result $deployment_specific_annotations }}
  {{- $result := merge $result $global_nonlbDeployment_annotations }}
  {{- $result := merge $result $global_allResources_annotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}


{{/*--------------------CustomExtension annotations for all kubernetes resources-----------------------------------------------------------*/}}
{{- define "custom.extensions.annotations.allResources" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- range $key, $value := $global_allResources_annotations }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*##############################           CustomExtension ANNOTATIONS section END       #############################################
########################################################################################################################################*/}}


{{/*###############################################################################################################################
##################################       Merged LABELS section START             ##################################################*/}}

{{/*-----------Labels for Lb Services-----------------*/}}
{{- define "labels.lbServices" -}}
{{- include "custom.extensions.labels.lbServices" . }}
{{- include "engineering.labels" . | nindent 4 }}
{{- end -}}

{{/*-----------Labels for NonLb Services-----------------*/}}
{{- define "labels.nonlbServices" -}}
{{- include "custom.extensions.labels.nonlbServices" . }}
{{- include "engineering.labels" . | nindent 4 }}
{{- end -}}

{{/*-----------Labels for NonLb Cache Services-----------------*/}}
{{- define "labels.nonlbCacheServices" -}}
{{- include "custom.extensions.labels.nonlbCacheServices" . }}
{{- include "engineering.labels" . | nindent 4 }}
{{- end -}}

{{/*-----------Labels for Lb Deployments-----------------*/}}
{{- define "labels.lbDeployments" -}}
{{- include "custom.extensions.labels.lbDeployments" . }}
{{- include "engineering.labels" . | nindent 4 }}
{{- end -}}

{{/*-----------Labels for nonlb Deployments-----------------*/}}
{{- define "labels.nonlbDeployments" -}}
{{- include "custom.extensions.labels.nonlbDeployments" . }}
{{- include "engineering.labels" . | nindent 4 }}
{{- end -}}

{{/*-----------Labels for All kubernetes resources-----------------*/}}
{{- define "labels.allResources" -}}
{{- include "custom.extensions.labels.allResources" . }}
{{- include "engineering.labels" . | nindent 4 }}
{{- end -}}

{{/*-----------Labels for hook resources-----------------*/}}
{{- define "labels.hooks" -}}
{{- include "custom.extensions.labels.allResources" . }}
{{- include "engineering.hooks.labels" . | nindent 4 }}
{{- end -}}

{{/*-----------Custom header inclusion check in IGW http response ---------*/}}
{{- define "includeCustomGwHeadersInResp.check" -}}
{{ .Values.includeCustomGwHeadersInResp | quote}}
{{- end -}}

{{/*##############################    Merged LABELS section END            #############################################################
########################################################################################################################################*/}}




{{/*###############################################################################################################################
##################################       Merged ANNOTATIONS section START        ##################################################*/}}
{{/*-----------Annotations for Lb Services-----------------*/}}
{{- define "annotations.lbServices" -}}
{{- include "custom.extensions.annotations.lbServices" . }}
{{- include "engineering.annotations" . | nindent 4 }}
{{- end -}}

{{/*-----------Annotations for NonLb Services-----------------*/}}
{{- define "annotations.nonlbServices" -}}
{{- include "custom.extensions.annotations.nonlbServices" . }}
{{- include "engineering.annotations" . | nindent 4 }}
{{- end -}}

{{/*-----------Annotations for NonLb Cache Services-----------------*/}}
{{- define "annotations.nonlbCacheServices" -}}
{{- include "custom.extensions.annotations.nonlbCacheServices" . }}
{{- include "engineering.annotations" . | nindent 4 }}
{{- end -}}

{{/*-----------Annotations for Lb Deployments-----------------*/}}
{{- define "annotations.lbDeployments" -}}
{{- include "custom.extensions.annotations.lbDeployments" . }}
{{- include "engineering.annotations" . | nindent 4 }}
{{- end -}}

{{/*-----------Annotations for nonLb Deployments-----------------*/}}
{{- define "annotations.nonlbDeployments" -}}
{{- include "custom.extensions.annotations.nonlbDeployments" . }}
{{- include "engineering.annotations" . | nindent 4 }}
{{- end -}}

{{/*-----------Annotations for All kubernetes resources-----------------*/}}
{{- define "annotations.allResources" -}}
{{- include "custom.extensions.annotations.allResources" . }}
{{- include "engineering.annotations" . | nindent 4 }}
{{- end -}}

{{/*##############################   Merged ANNOTATIONS section END       #############################################################
########################################################################################################################################*/}}




{{/*--------------------Common Tolerations----------------------------------------------------------------------*/}}
{{- define "ocnf.tolerations" }}
 {{- $localTolerationsSetting := .Values.tolerationsSetting | default "USE_GLOBAL_VALUE" }}
 {{- $globalTolerationsSetting := .Values.global.tolerationsSetting | default "DISABLED" }}
 {{- $tolerations := "" }}

 {{- if (eq $localTolerationsSetting "ENABLED") }}
   {{- $tolerations =  .Values.tolerations }}
 {{- else if (eq $localTolerationsSetting "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalTolerationsSetting "ENABLED")}}
     {{- $tolerations = .Values.global.tolerations }}
   {{- end }}
 {{- end }}

 {{- if $tolerations }}
{{- toYaml $tolerations }}
 {{- end }}
{{- end }}
{{/*--------------------Common NodeSelector----------------------------------------------------------------------*/}}
{{- define "ocnf.nodeselector" }}
 {{- $localNodeSelection := .Values.nodeSelection | default "USE_GLOBAL_VALUE" }}
 {{- $globalNodeSelection := .Values.global.nodeSelection | default "DISABLED" }}
 {{- $nodeselector := "" }}

 {{- if (eq $localNodeSelection "ENABLED") }}
   {{- $nodeselector =  .Values.nodeSelector }}
 {{- else if (eq $localNodeSelection "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalNodeSelection "ENABLED")}}
     {{- $nodeselector = .Values.global.nodeSelector }}
   {{- end }}
 {{- end }}

 {{- if $nodeselector }}
{{- toYaml $nodeselector }}
 {{- end }}
{{- end }}

{{/*----------INIT CONTAINER ENABLE CHECK-------------*/}}
{{- define "initcontainer.enabled" -}}
 {{- if or .Values.initssl (and .Values.messageCopy.enabled .Values.messageCopy.security.enabled) -}}
  {{- printf "true" -}}
 {{- else -}}
  {{- printf "false" -}}
 {{- end -}}
{{- end -}}

{{/*------------------- CCA Header Validation Cache size -------------------------------------------------------------*/}}
{{- define "ccaHeaderValidation.cacheSize" -}}
  {{- 500 }}
{{- end -}}


{{/*------------------- CNCC sections starts -------------------------------------------------------------*/}}
{{/***************************************************************************************************************
     Any custom lables/variables related to CNCC will be defined here.
   ***************************************************************************************************************/}}
{{- define "cncc.servicemesh.httpsEnabled" -}}
  {{- true | quote }}
{{- end -}}

{{- define "cncc.primaryIssuer" -}}
  {{ index .Values.cncc.iam.issuers 0 }}
{{- end -}}
{{- define "cncc.iam.userId" -}}
  {{- "UNKNOWN" | quote }}
{{- end -}}

{{- define "cncc.iam.userName" -}}
  {{- "UNKNOWN" | quote }}
{{- end -}}

{{- define "cncc.onlyResourceServerEnabled" -}}
  {{ .Values.cncc.onlyResourceServerEnabled | default false }}
{{- end -}}


{{- define "xfccHeaderValidation.validation.dnsResolutionInterval" -}}
  {{- if and (mustRegexMatch "^[0-9]+$" (toString (.Values.global.xfccHeaderValidation.validation.dnsResolutionInterval | int64 ))) (gt (.Values.global.xfccHeaderValidation.validation.dnsResolutionInterval | float64 | int64) 0) }}
  {{- .Values.global.xfccHeaderValidation.validation.dnsResolutionInterval | int64 -}}
  {{- else}}
  {{- fail "dnsResolutionInterval must be positive integer value greater than zero. If the value is a positive decimal value, the result value will be the whole number part" }}
  {{- end}}
{{- end -}}

{{- define "cncc.resourceRolesConfigMap" -}}
  {{- "cncc-resourceroles" -}}
{{- end -}}

{{- define "cncc.isResourceLevelAuthorizationEnabledNFsNotEmpty" -}}
  {{- false }}
{{- end -}}

{{- define "cncc.iam.issuers" -}}
        {{- $prefix := .Values.cncc.iam.prefix }}
        {{- $realm := .Values.cncc.iam.realm }}
        {{- range .Values.cncc.iam.issuers }}
          - {{.}}{{ $prefix }}/realms/{{ $realm }}
        {{- end -}}
{{- end -}}


{{- define "cncc.iam.allowedURLs" -}}
        {{- $allowedURLs := .Values.allowedURLs | default (list) -}}
        {{- range $allowedURLs }}
          - {{ . }}
        {{- end -}}
{{- end -}}

{{- define "cncc.mimcConfig" -}}
    multi-instance-multi-cluster-config:
      multiClusterMultiInstanceEnabled: false
      siteBasedAuthorizationEnabled: false
      instanceLevelAuthorizationEnabled: false
      cnccIdHeader: oc-cncc-id
      instanceIdHeader: oc-cncc-instance-id
      mCnccCores: []
      aCnccs: []
      instances: []
{{- end -}}

{{- define "cncc.loggingFilters" -}}
    logging-filters:
      headers:
      {{- range $val := .Values.log.level.cncc.loggingFilters }}
        - header: {{ .headerName }}
          {{- if $val.headerValues }}
          value:
          {{- range  $val.headerValues }}
            - {{ . }}
          {{- end -}}
          {{- end -}}
      {{- end -}}
{{- end -}}

{{- define "cncc.loggingMasks" -}}
    logging-masks:
      masks:
      {{- range $val := .Values.log.level.cncc.loggingMasks }}
        - uri: {{ .uri }}
          {{- if .regexUri }}
          regexUri: {{ .regexUri }}
          {{- end -}}
          {{- if $val.keys }}
          keys:
          {{- range  $val.keys }}
            - {{ . }}
          {{- end -}}
          {{- end -}}
      {{- end -}}
{{- end -}}

{{- define "log.discarding" -}}
    log-discarding:
      enabled: {{ .Values.log.discarding.enabled }}
      featureToThresholdMapping:
    {{- range .Values.log.discarding.featureToThresholdMapping }}
    {{- if .feature }}
      - feature: {{ .feature | quote }}
        thresholdFactor: {{ .thresholdFactor }}
    {{- end }}
    {{- end }}
{{- end -}}

{{/******* CNCC Security Config *******/}}
{{- define "cncc.security" }}
    {{- if .Values.cncc.enabled }}
      {{- if eq ( include "cncc.onlyResourceServerEnabled" . ) "false" }}
      {{ include "cncc.security.clientConfig" . }}
      {{- end }}
    {{- else }}
      autoconfigure:
        exclude: ${spring.autoconfigure.rsac}, ${spring.autoconfigure.rusac}, ${spring.autoconfigure.rmwsas}
        rsac: org.springframework.boot.autoconfigure.security.reactive.ReactiveSecurityAutoConfiguration
        rusac: org.springframework.boot.autoconfigure.security.reactive.ReactiveUserDetailsServiceAutoConfiguration
        rmwsas: org.springframework.boot.actuate.autoconfigure.security.reactive.ReactiveManagementWebSecurityAutoConfiguration
    {{- end }}
{{- end }}

{{- define "cncc.security.clientConfig" }}
      {{- if and (index .Values.global "oci-iam") (index .Values.global "oci-iam" "enabled") }}
      security:
        oauth2:
          client:
            registration:
              cncc-iam:
                client-id: ${OCI_IAM_CLIENTID}
                client-secret: ${OCI_IAM_CLIENTSECRET}
                authorization-grant-type: authorization_code
                redirect-uri: '{baseUrl}/login/oauth2/code/{registrationId}'
                client-authentication-method: client_secret_basic
            provider:
              cncc-iam:
                issuer-uri: {{ template "cncc.primaryIssuer" . }}
                user-name-attribute: user_displayname
      {{- else }}
      security:
        oauth2:
          client:
            registration:
              cncc-iam:
                client-id: cncc
                authorization-grant-type: authorization_code
                redirect-uri: '{baseUrl}/login/oauth2/code/{registrationId}'
                client-authentication-method: none
            provider:
              cncc-iam:
                issuer-uri: {{ template "cncc.primaryIssuer" . }}
                user-name-attribute: preferred_username
      {{- end }}
{{- end }}

{{/*------------------- CNCC sections ends -------------------------------------------------------------*/}}


{{/*---------------------DualStack: IGW ipFamily config-----------------------------------------------------------*/}}
{{- define "dualStack.igw.ipFamilies" }}

{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}
{{- $IPFamilyPolicies := list "SingleStack" "RequireDualStack" }}


{{- if  and (has .Values.global.deploymentMode $validDeploymentModes) (ne .Values.global.deploymentMode "ClusterPreferred") }}
{{- if or (eq .Values.global.deploymentMode "IPv4") (eq .Values.global.deploymentMode "IPv6") }}
  ipFamilyPolicy: {{ index $IPFamilyPolicies 0 }}
  ipFamilies:
  - {{ .Values.global.deploymentMode }}
{{- else }}
  ipFamilyPolicy: {{ index $IPFamilyPolicies 1 }}
  ipFamilies:
  {{- if (eq .Values.global.deploymentMode "IPv4_IPv6")}}
  - IPv4
  - IPv6
  {{- else }}
  - IPv6
  - IPv4
  {{- end }}
{{- end }}
{{- end }}

{{- end }}

{{/*--------------------DualStack: Deployment Mode------------------------------------------------*/}}
{{- define "dualStack.igw.deploymentMode" }}
{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}
{{- if has .Values.global.deploymentMode $validDeploymentModes }}
{{- .Values.global.deploymentMode }}
{{- else }}
{{- "ClusterPreferred" }}
{{- end}}
{{- end }}

{{/*----------------------------------Connection Level Circuit Breaker Start------------------------------------*/}}
{{- define "validate-connection-level-circuit-breaking" }}
    {{/* Validate timeoutThreshold */}}
    {{- if not (regexMatch "^\\d+$" (.Values.connectionLevelCircuitBreaking.timeoutThreshold | toString)) }}
        {{ fail (printf "Invalid timeoutThreshold value %s. It must be a non-negative integer." (.Values.connectionLevelCircuitBreaking.timeoutThreshold | quote)) }}
    {{- end }}
    {{- if lt (int .Values.connectionLevelCircuitBreaking.timeoutThreshold) 1 }}
        {{ fail (printf "Invalid timeoutThreshold value %s. It must be greater than 0." (.Values.connectionLevelCircuitBreaking.timeoutThreshold | quote)) }}
    {{- end }}

    {{/* Validate thresholdPercentage */}}
    {{- if lt (int .Values.connectionLevelCircuitBreaking.thresholdPercentage) 0 }}
        {{ fail (printf "Invalid thresholdPercentage value %s. It must be greater than or equal to 0.0" (.Values.connectionLevelCircuitBreaking.thresholdPercentage | quote)) }}
    {{- end }}
{{- end}}
{{/*-----------------------------------Connection Level Circuit Breaker End-------------------------------------*/}}

{{/*---------------------DualStack: coherence ipFamily config-----------------------------------------------------------*/}}
{{- define "dualStack.igw.coherence.ipFamilies" }}

{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}

{{- if and (has .Values.global.deploymentMode $validDeploymentModes) (ne .Values.global.deploymentMode "ClusterPreferred") }}
  ipFamilyPolicy: SingleStack
  ipFamilies:
  {{- if or (eq .Values.global.deploymentMode "IPv4") (eq .Values.global.deploymentMode "IPv4_IPv6") }}
  - IPv4
  {{- else }}
  - IPv6
  {{- end }}
{{- end }}

{{- end }}
