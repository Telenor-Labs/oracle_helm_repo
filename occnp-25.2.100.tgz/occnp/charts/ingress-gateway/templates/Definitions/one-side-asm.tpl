{{/*----------------------------------service discovery configuration section start------------------------------------*/}}
{{ include "validate-one-side-asm" . -}}

{{- define "service.discovery.mechanism" -}}
{{- $validValues := list "" "DNS" "KUBERNETES" }}
{{- $serviceDiscoveryMechanism := .Values.serviceDiscoveryMechanism | trim }}
{{- if not (has $serviceDiscoveryMechanism $validValues) }}
  {{- $displayValues := join ", " (list "no value (blank)" "DNS" "KUBERNETES") }}
  {{- fail (printf "Invalid serviceDiscoveryMechanism value '%s'. Supported values are [%v]" $serviceDiscoveryMechanism $displayValues) }}
{{- end }}
{{- if eq $serviceDiscoveryMechanism "" }}
  {{- if and .Values.serviceMeshCheck .Values.intraNfServiceMesh }}
    {{- printf "DNS" }}
  {{- else }}
    {{- printf "KUBERNETES" }}
  {{- end }}
{{- else }}
  {{- printf "%s" $serviceDiscoveryMechanism }}
{{- end }}
{{- end -}}
{{/*----------------------------------service discovery configuration section end------------------------------------*/}}