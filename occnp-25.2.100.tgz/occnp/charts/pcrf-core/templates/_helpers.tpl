Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "pcrf-core.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "service-prefix" -}}
{{- if .Values.global.nfName -}}
{{- printf "%s-%s" .Release.Name .Values.global.nfName | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "pcrf-core-deployment-name" -}}
{{- printf "%s-%s" .Release.Name "pcrf-core" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "pcrf-core-headless-label-name" -}}
{{- printf "%s-%s" .Release.Name "pcrf-core-headless" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "pcrf-core-hook-name-pre-install" -}}
{{- printf "%s-%s-%s" .Release.Name "pcrf-core" "pre-install" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "pcrf-core-hook-name-post-install" -}}
{{- printf "%s-%s-%s" .Release.Name "pcrf-core" "post-install" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "pcrf-core-hook-name-pre-upgrade" -}}
{{- printf "%s-%s-%s" .Release.Name "pcrf-core" "pre-upgrade" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "pcrf-core-hook-name-post-upgrade" -}}
{{- printf "%s-%s-%s" .Release.Name "pcrf-core" "post-upgrade" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "pcrf-core-hook-name-pre-rollback" -}}
{{- printf "%s-%s-%s" .Release.Name "pcrf-core" "pre-rollback" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "pcrf-core-hook-name-post-rollback" -}}
{{- printf "%s-%s-%s" .Release.Name "pcrf-core" "post-rollback" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "pcrf-core-hook-name-pre-delete" -}}
{{- printf "%s-%s-%s" .Release.Name "pcrf-core" "pre-delete" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "pcrf-core-hook-name-post-delete" -}}
{{- printf "%s-%s-%s" .Release.Name "pcrf-core" "post-delete" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-container" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "hook-container" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*--------------------------Ephemeral Storage-------------------------------------------------------------*/}}
{{- define "pcrf-core-ephemeral-storage-request" -}}
 {{- div (mul (add .Values.global.logStorage .Values.global.crictlStorage) 11) 10 -}}Mi
{{- end -}}

{{- define "pcrf-core-hpa-name" -}}
{{- printf "%s-%s" .Release.Name "pcrf-core-hpa" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "service-name-usage-mon" -}}
{{- printf "%s-%s" (include "service-prefix" .) "usage-mon" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Common Service Account Name---------------------------------------------------------------*/}}
{{- define "ocnf.serviceaccount" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}-serviceaccount
{{- end -}}


{{/*--------------------------------------Debug Tool Container---------------------------------------------------*/}}
{{- define "extraContainers" -}} 
  {{- if (eq .Values.extraContainers "ENABLED") -}} 
    {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}} 
    {{- if (eq .Values.global.extraContainers "ENABLED") -}} 
      {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
    {{- end -}} 
  {{- end -}} 
{{- end -}} 

{{- define "extraVolumes" -}}
  {{- if (eq .Values.extraContainers "ENABLED") -}}
    {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}}
    {{- if (eq .Values.global.extraContainers "ENABLED") -}}
      {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
    {{- end -}}
  {{- end -}}
{{- end -}}


{{/*--------------------Common NodeSelector----------------------------------------------------------------------*/}}
{{- define "ocnf.nodeselector" }}
 {{- $localNodeSelection := .Values.nodeSelection | default "USE_GLOBAL_VALUE" }}
 {{- $globalNodeSelection := .Values.global.nodeSelection | default "DISABLED" }}
 {{- $nodeselector := "" }}

 {{- if (eq $localNodeSelection "ENABLED") }}
   {{- $nodeselector =  .Values.nodeSelector }}
 {{- else if (eq $localNodeSelection "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalNodeSelection "ENABLED")}}
     {{- $nodeselector = .Values.global.nodeSelector }}
   {{- end }}
 {{- end }}

 {{- if $nodeselector }}
{{- toYaml $nodeselector }}
 {{- end }}
{{- end }}

{{/*---------------------DualStack: ipFamily config-----------------------------------------------------------*/}}
{{- define "dualStack.pcrfCore.ipFamilies" }}

{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}

{{- if  and (has .Values.global.deploymentMode $validDeploymentModes) (ne .Values.global.deploymentMode "ClusterPreferred") }}
  ipFamilyPolicy: SingleStack
  ipFamilies:
  {{- if or (eq .Values.global.deploymentMode "IPv4") (eq .Values.global.deploymentMode "IPv4_IPv6") }}
  - IPv4
  {{- else }}
  - IPv6
  {{- end }}
{{- end }}

{{- end }}

{{/*--------------------DualStack: Deployment Mode------------------------------------------------*/}}
{{- define "dualStack.deploymentMode" }}
{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}
{{- if has .Values.global.deploymentMode $validDeploymentModes }}
{{- .Values.global.deploymentMode }}
{{- else }}
{{- "ClusterPreferred" }}
{{- end}}
{{- end }}