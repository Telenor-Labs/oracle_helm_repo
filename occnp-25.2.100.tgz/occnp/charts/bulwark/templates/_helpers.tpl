{{/*
    Create a default fully qualified app name.
    We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
    If release name contains chart name it will be used as a full name.
*/}}

{{- define "bulwark-service.fullname" -}}
  {{- if .Values.fullnameOverride -}}
    {{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
  {{- else -}}
    {{- $name := default .Chart.Name .Values.nameOverride -}}
    {{- if contains $name .Release.Name -}}
      {{- .Release.Name | trunc 63 | trimSuffix "-" -}}
    {{- else -}}
      {{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- define "service-prefix" -}}
  {{- if .Values.global.nfName -}}
    {{- printf "%s-%s" .Release.Name .Values.global.nfName | trunc 63 | trimSuffix "-" -}}
  {{- else -}}
    {{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
  {{- end -}}
{{- end -}}

{{- define "service-name-bulwark" -}}
{{- include "service-prefix" . }}-bulwark
{{- end -}}

{{/*------------------- get prefix ------------------------------*/}}
{{- define "getprefix" -}}
{{  default "" .Values.global.k8sResource.container.prefix | lower }}
{{- end -}}

{{/*------------------- getsuffix. ---------------------------------*/}}
{{- define "getsuffix" -}}
{{  default "" .Values.global.k8sResource.container.suffix | lower }}
{{- end -}}

{{/*--------------------Expand the name of the container.----------------------*/}}
{{- define "container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s" $prefix (include "chart.fullname" . ) $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{- define "bulwarkservice-deployment-name" -}}
{{- printf "%s-%s" .Release.Name "bulwark" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "bulwarkservice-hpa-name" -}}
{{- printf "%s-%s" .Release.Name "bulwark-hpa" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Coherence-----------------------------*/}}
{{- define "bulwark-service-coherence-headless-service-label" -}}
{{- printf "%s-%s" .Release.Name "bulwark-service" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "service-name-bulwark-service-coherence-headless" -}}
{{- printf "%s-%s" (include "service-prefix" .) "bulwark-coherence-headless" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "service-name-config-server" -}}
{{- printf "%s-%s" (include "service-prefix" .) "config-server" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "chart.fullname" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "bulwark.serviceaccount" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}-bulwark-serviceaccount
{{- end -}}

{{- define "bulwark.role" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}-bulwark-role
{{- end -}}

{{- define "bulwark.rolebinding" -}}
{{ .Release.Name | trunc 63 | trimSuffix "-" -}}-bulwark-rolebinding
{{- end -}}

{{/*-------------------- annotations deployment ------------------------*/}}
{{- define "annotations.deployments" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- $global_deployment_annotations := .Values.global.customExtension.nonlbDeployments.annotations -}}
  {{- if .Values.useLbLabelsAndAnnotations }}
    {{- $global_deployment_annotations = .Values.global.customExtension.lbDeployments.annotations -}}
  {{- end -}}
  {{- $deployment_specific_annotations := .Values.deployment.customExtension.annotations -}}
  {{- $result := dict }}
  {{- $result := merge $result $deployment_specific_annotations  }}
  {{- $result := merge $result $global_deployment_annotations }}
  {{- $result := merge $result $global_allResources_annotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
  {{- include "engineering.annotations" . | nindent 4 }}
  {{- include "factory.annotations" . }}
{{- end -}}

{{- define "engineering.annotations" -}}
{{- end -}}

{{- define "factory.annotations" -}}
  {{- range $key, $value := $.Values.global.customExtension.factoryAnnotationsTemplates }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ tpl $value $ }}
  {{- end }}
{{- end -}}

{{/*-------------------- labels deployment ------------------------*/}}
{{- define "labels.deployments" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- $global_deployment_labels := .Values.global.customExtension.nonlbDeployments.labels -}}
  {{- if .Values.useLbLabelsAndAnnotations }}
    {{- $global_deployment_labels = .Values.global.customExtension.lbDeployments.labels }}
  {{- end }}
  {{- $deployment_specific_labels := .Values.deployment.customExtension.labels -}}
  {{- $result := dict }}
  {{- $result := merge $result $deployment_specific_labels }}
  {{- $result := merge $result $global_deployment_labels }}
  {{- $result := merge $result $global_allResources_labels }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
  {{- include "engineering.labels" . | nindent 4 }}
  {{- include "factory.labels" . }}
{{- end -}}

{{- define "engineering.labels" -}}
app.kubernetes.io/name: '{{ template "chart.fullname" . }}'
helm.sh/chart: '{{ template "chart.fullnameandversion" . }}'
app.kubernetes.io/instance: '{{ .Release.Name }}'
app.kubernetes.io/managed-by: '{{ .Release.Service }}'
app.kubernetes.io/version: '{{ .Chart.AppVersion }}'
app.kubernetes.io/part-of: occnp
application: occnp
microservice: {{ .Values.fullnameOverride | default (printf "%s-%s" (default "occnp" .Values.appName) (include "chart.fullname" . )) }}
engVersion: {{ .Chart.Version | quote }}
mktgVersion: {{ .Chart.AppVersion | quote }}
vendor: Oracle
{{- end -}}

{{/*--------------------Create chart name and version as used by the chart label.---------------------------------*/}}
{{- define "chart.fullnameandversion" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "factory.labels" -}}
  {{- range $key, $value := $.Values.global.customExtension.factoryLabelTemplates }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ tpl $value $ }}
  {{- end }}
{{- end -}}

{{/*-----------Labels for All kubernetes resources-----------------*/}}
{{- define "labels.allResources" -}}
{{- include "custom.extensions.labels.allResources" . }}
{{- include "engineering.labels" . | nindent 4 }}
{{- end -}}

{{/*----------- annotations for all kubernetes resources-----------------*/}}
{{- define "annotations.allResources" -}}
  {{- include "custom.extensions.annotations.allResources" . }}
  {{- include "engineering.annotations" . | nindent 4 }}
{{- end -}}

{{/*-------------------- annotations service ------------------------*/}}
{{- define "annotations.services" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- $global_services_annotations := .Values.global.customExtension.nonlbServices.annotations -}}
  {{- if .Values.useLbLabelsAndAnnotations }}
    {{- $global_services_annotations = .Values.global.customExtension.lbServices.annotations -}}
  {{- end -}}
  {{- $service_specific_annotations := .Values.service.customExtension.annotations -}}
  {{- $result := dict }}
  {{- $result := merge $result $service_specific_annotations }}
  {{- $result := merge $result $global_services_annotations }}
  {{- $result := merge $result $global_allResources_annotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
  {{- include "engineering.annotations" . | nindent 4 }}
  {{- include "factory.annotations" . }}
{{- end -}}

{{/*-------------------- labels services ------------------------*/}}
{{- define "labels.services" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- $global_services_labels := .Values.global.customExtension.nonlbServices.labels -}}
  {{- if .Values.useLbLabelsAndAnnotations -}}
     {{- $global_services_labels = .Values.global.customExtension.lbServices.labels -}}
  {{- end -}}
  {{- $service_specific_labels := .Values.service.customExtension.labels -}}
  {{- $result := dict }}
  {{- $result := merge $result $service_specific_labels }}
  {{- $result := merge $result $global_services_labels }}
  {{- $result := merge $result $global_allResources_labels }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
  {{- include "engineering.labels" . | nindent 4 }}
  {{- include "factory.labels" . }}
{{- end -}}

{{/*--------------------CustomExtension labels for all kubernetes resources-----------------------------------------------------------*/}}
{{- define "custom.extensions.labels.allResources" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- range $key, $value := $global_allResources_labels }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*--------------------CustomExtension annotations for all kubernetes resources-----------------------------------------------------------*/}}
{{- define "custom.extensions.annotations.allResources" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- range $key, $value := $global_allResources_annotations }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*----------------- Debug Tool Container--------------------------*/}}
{{- define "extraContainers" -}}
  {{- if (eq .Values.extraContainers "ENABLED") -}}
    {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}}
    {{- if (eq .Values.global.extraContainers "ENABLED") -}}
      {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- define "extraVolumes" -}}
  {{- if (eq .Values.extraContainers "ENABLED") -}}
    {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}}
    {{- if (eq .Values.global.extraContainers "ENABLED") -}}
      {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
    {{- end -}}
  {{- end -}}
{{- end -}}


{{/*--------------------------Ephemeral Storage-------------------------------------------------------------*/}}
{{- define "bulwark-service-ephemeral-storage-request" -}}
 {{- div (mul (add .Values.global.logStorage .Values.global.crictlStorage) 11) 10 -}}Mi
{{- end -}}

{{/*-------------------- Persistent configuration --------------------------------------------------------------------*/}}
{{- define "bulwark.defaultconfig.labels" -}}
logging:
  appLogLevel: {{ .Values.log.level.bulwark }}
  packageLogLevel:
  - packageName: root
    logLevelForPackage: {{ .Values.log.level.root }}
congestionConfiguration:
  activeThresholdProfile: DEFAULT
  stateChangeSampleCount: 5
  stateCalculationInterval: 200
  enable: false
congestionThresholdProfiles:
  - name: DEFAULT
    value:
      - state: DANGER_OF_CONGESTION
        resourceUsageLimit:
          cpu: 80
          queue: 75
      - state: CONGESTED
        resourceUsageLimit:
          cpu: 90
          queue: 85
    isCustomProfile: false
congestionLoadSheddingProfile:
  - name: loadSheddingProfile
    type: congestion
    loadSheddingRuleName: DEFAULT
congestionLoadSheddingRules:
  - name: DEFAULT
    value:
      - state: DANGER_OF_CONGESTION
        discardPriority: 20
      - state: CONGESTED
        discardPriority: 10
    isCustomProfile: false
congestionConfigurationV2:
  activeThresholdProfile: DEFAULT
  stateChangeSampleCount: 5
  stateCalculationInterval: 200
  enable: false
  advancedSettings: []
congestionThresholdProfilesV2:
  - name: DEFAULT
    value:
      - state: DANGER_OF_CONGESTION
        resourceUsageLimit:
          cpu: 60
          queue: 6300
      - state: CONGESTION_L1
        resourceUsageLimit:
          cpu: 70
          queue: 7200
      - state: CONGESTION_L2
        resourceUsageLimit:
          cpu: 80
          queue: 8100
      - state: CONGESTED
        resourceUsageLimit:
          cpu: 90
          queue: 9000
    isCustomProfile: false
congestionLoadSheddingProfileV2:
  - name: loadSheddingProfile
    type: congestion
    loadSheddingRuleName: DEFAULT
congestionLoadSheddingRulesV2:
  - name: DEFAULT
    value:
      - state: DANGER_OF_CONGESTION
        discardPriority: 27
      - state: CONGESTION_L1
        discardPriority: 19
      - state: CONGESTION_L2
        discardPriority: 17
      - state: CONGESTED
        discardPriority: 15
    isCustomProfile: false
congestionMigrationStatus:
  migrated: true
  attempts: 0
  cause: ""
settings:
  serverRetryOnAlreadyLocked:
    enabled: false
    maxPendingLockRequestsPerKey: 5
  advancedSettings: []
{{- end -}}

{{/*--------------------Common Config server Service Name------------------------------------------------------------*/}}
{{- define "service.ConfigServerSvcFullname" -}}
{{- if .Values.commonCfgServer.configServerSvcName -}}
{{- $name := .Values.commonCfgServer.configServerSvcName -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- else -}}
{{- .Values.commonCfgServer.host | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}


{{/*-------------------- Job Name for Pre-Install .--------------------------------*/}}
{{- define "pre-install-bulwark-job.fullname" -}}
{{- printf "%s-%s" (include "service-name-bulwark" .) "pre-install" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the pre-install container.--------------------------------*/}}
{{- define "pre-install-bulwark-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service-name-bulwark" .) "pre-install" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Pre-Upgrade .--------------------------------*/}}
{{- define "pre-upgrade-bulwark-job.fullname" -}}
{{- printf "%s-%s" (include "service-name-bulwark" .) "pre-upgrade" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the pre-upgrade container.--------------------------------*/}}
{{- define "pre-upgrade-bulwark-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service-name-bulwark" .) "pre-upgrade" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Pre-Rollback .--------------------------------*/}}
{{- define "pre-rollback-bulwark-job.fullname" -}}
{{- printf "%s-%s" (include "service-name-bulwark" .) "pre-rollback" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the pre-rollback container.--------------------------------*/}}
{{- define "pre-rollback-bulwark-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service-name-bulwark" .) "pre-rollback" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Pre-Delete .--------------------------------*/}}
{{- define "pre-delete-bulwark-job.fullname" -}}
{{- printf "%s-%s" (include "service-name-bulwark" .) "pre-delete" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the pre-delete container.--------------------------------*/}}
{{- define "pre-delete-bulwark-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service-name-bulwark" .) "pre-delete" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Post-Upgrade .--------------------------------*/}}
{{- define "post-upgrade-bulwark-job.fullname" -}}
{{- printf "%s-%s" (include "service-name-bulwark" .) "post-upgrade" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the post-upgrade container.--------------------------------*/}}
{{- define "post-upgrade-bulwark-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service-name-bulwark" .) "post-upgrade" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*-------------------- Job Name for Post-Rollback .--------------------------------*/}}
{{- define "post-rollback-bulwark-job.fullname" -}}
{{- printf "%s-%s" (include "service-name-bulwark" .) "post-rollback" | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the post-rollback container.--------------------------------*/}}
{{- define "post-rollback-bulwark-job.container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s-%s" $prefix (include "service-name-bulwark" .) "post-rollback" $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Common Tolerations----------------------------------------------------------------------*/}}
{{- define "ocnf.tolerations" }}
 {{- $localTolerationsSetting := .Values.tolerationsSetting | default "USE_GLOBAL_VALUE" }}
 {{- $globalTolerationsSetting := .Values.global.tolerationsSetting | default "DISABLED" }}
 {{- $tolerations := "" }}

 {{- if (eq $localTolerationsSetting "ENABLED") }}
   {{- $tolerations =  .Values.tolerations }}
 {{- else if (eq $localTolerationsSetting "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalTolerationsSetting "ENABLED")}}
     {{- $tolerations = .Values.global.tolerations }}
   {{- end }}
 {{- end }}

 {{- if $tolerations }}
{{- toYaml $tolerations }}
 {{- end }}
{{- end }}
{{/*--------------------Common NodeSelector----------------------------------------------------------------------*/}}
{{- define "ocnf.nodeselector" }}
 {{- $localNodeSelection := .Values.nodeSelection | default "USE_GLOBAL_VALUE" }}
 {{- $globalNodeSelection := .Values.global.nodeSelection | default "DISABLED" }}
 {{- $nodeselector := "" }}

 {{- if (eq $localNodeSelection "ENABLED") }}
   {{- $nodeselector =  .Values.nodeSelector }}
 {{- else if (eq $localNodeSelection "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalNodeSelection "ENABLED")}}
     {{- $nodeselector = .Values.global.nodeSelector }}
   {{- end }}
 {{- end }}

 {{- if $nodeselector }}
{{- toYaml $nodeselector }}
 {{- end }}
{{- end }}
{{/*--------------------bulwark.hook.chartVersion--------------------------------------------*/}}
{{- define "bulwark.hook.chartVersion" -}}
{{- .Chart.Version | trunc 9 | trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Service mesh check flag------------------------------------------------*/}}
{{- define "servicemesh.check" -}}
{{ .Values.serviceMeshCheck | quote }}
{{- end -}}

{{/*--------------------istio sidecar ready URL------------------------------------------------*/}}
{{- define "istioproxy.ready.url" -}}
{{ .Values.istioSidecarReadyUrl | quote }}
{{- end -}}

{{/*--------------------istio sidecar quit URL------------------------------------------------*/}}
{{- define "istioproxy.quit.url" -}}
{{ .Values.istioSidecarQuitUrl | quote }}
{{- end -}}

{{/*---------------------DualStack: ipFamily config-----------------------------------------------------------*/}}
{{- define "dualStack.bulwark.ipFamilies" }}

{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}

{{- if  and (has .Values.global.deploymentMode $validDeploymentModes) (ne .Values.global.deploymentMode "ClusterPreferred") }}
  ipFamilyPolicy: SingleStack
  ipFamilies:
  {{- if or (eq .Values.global.deploymentMode "IPv4") (eq .Values.global.deploymentMode "IPv4_IPv6") }}
  - IPv4
  {{- else }}
  - IPv6
  {{- end }}
{{- end }}

{{- end }}

{{/*--------------------DualStack: Deployment Mode------------------------------------------------*/}}
{{- define "dualStack.deploymentMode" }}
{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}
{{- if has .Values.global.deploymentMode $validDeploymentModes }}
{{- .Values.global.deploymentMode }}
{{- else }}
{{- "ClusterPreferred" }}
{{- end}}
{{- end }}