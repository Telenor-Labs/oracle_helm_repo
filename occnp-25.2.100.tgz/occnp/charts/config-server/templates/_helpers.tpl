{{/*Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "config-server.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "service-prefix" -}}
{{- if .Values.global.nfName -}}
{{- printf "%s-%s" .Release.Name .Values.global.nfName | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "pdb-max-unavailiable" -}}
{{- if .Values.pdbMaxUnavailable -}}
{{- printf "%s"  .Values.pdbMaxUnavailable -}}
{{- else if .Values.maxUnavailable -}}
{{- printf "%s" .Values.maxUnavailable -}}
{{- else -}}
{{- printf "%s"  .Values.pdb.maxUnavailable -}}
{{- end -}}
{{- end -}}

{{- define "config-server-deployment-name" -}}
{{- printf "%s-%s" .Release.Name .Values.global.configServerFullNameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "service-name-config-server" -}}
{{- printf "%s-%s" (include "service-prefix" .) "config-server" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-hpa-name" -}}
{{- printf "%s-%s" .Release.Name "config-server-hpa" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-hook-name-pre-install" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "pre-install" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-hook-name-post-install" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "post-install" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-hook-name-pre-upgrade" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "pre-upgrade" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-hook-name-post-upgrade" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "post-upgrade" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-hook-name-pre-rollback" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "pre-rollback" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-hook-name-post-rollback" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "post-rollback" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-hook-name-pre-delete" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "pre-delete" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-hook-name-post-delete" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "post-delete" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{/*--------------------Common Tolerations----------------------------------------------------------------------*/}}
{{- define "ocnf.tolerations" }}
 {{- $localTolerationsSetting := .Values.tolerationsSetting | default "USE_GLOBAL_VALUE" }}
 {{- $globalTolerationsSetting := .Values.global.tolerationsSetting | default "DISABLED" }}
 {{- $tolerations := "" }}

 {{- if (eq $localTolerationsSetting "ENABLED") }}
   {{- $tolerations =  .Values.tolerations }}
 {{- else if (eq $localTolerationsSetting "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalTolerationsSetting "ENABLED")}}
     {{- $tolerations = .Values.global.tolerations }}
   {{- end }}
 {{- end }}

 {{- if $tolerations }}
{{- toYaml $tolerations }}
 {{- end }}
{{- end }}
{{/*--------------------Common NodeSelector----------------------------------------------------------------------*/}}
{{- define "ocnf.nodeselector" }}
 {{- $localNodeSelection := .Values.nodeSelection | default "USE_GLOBAL_VALUE" }}
 {{- $globalNodeSelection := .Values.global.nodeSelection | default "DISABLED" }}
 {{- $nodeselector := "" }}

 {{- if (eq $localNodeSelection "ENABLED") }}
   {{- $nodeselector =  .Values.nodeSelector }}
 {{- else if (eq $localNodeSelection "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalNodeSelection "ENABLED")}}
     {{- $nodeselector = .Values.global.nodeSelector }}
   {{- end }}
 {{- end }}

 {{- if $nodeselector }}
{{- toYaml $nodeselector }}
 {{- end }}
{{- end }}

{{/*--------------------------Ephemeral Storage-------------------------------------------------------------*/}}
{{- define "config-server-ephemeral-storage-request" -}}
 {{- div (mul (add .Values.global.logStorage .Values.global.crictlStorage) 11) 10 -}}Mi
{{- end -}}

{{/*--------------------------Graceful Termination-------------------------------------------------------------*/}}
{{- define "termination-grace-period-seconds" -}}
{{- if contains "s" .Values.gracefulShutdown.gracePeriod -}}
{{- .Values.gracefulShutdown.gracePeriod | trimSuffix "s" -}}
{{- else if contains "m" .Values.gracefulShutdown.gracePeriod -}}
{{- mul ( .Values.gracefulShutdown.gracePeriod | trimSuffix "m") 60 -}}
{{- end -}}
{{- end -}}

{{/*--------------------------------------Debug Tool Container---------------------------------------------------*/}}
{{- define "extraContainers" -}} 
  {{- if (eq .Values.extraContainers "ENABLED") -}} 
    {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}} 
    {{- if (eq .Values.global.extraContainers "ENABLED") -}} 
      {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
    {{- end -}} 
  {{- end -}} 
{{- end -}} 

{{- define "extraVolumes" -}}
  {{- if (eq .Values.extraContainers "ENABLED") -}}
    {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}}
    {{- if (eq .Values.global.extraContainers "ENABLED") -}}
      {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*---------------------DualStack: ipFamily config-----------------------------------------------------------*/}}
{{- define "dualStack.configServer.ipFamilies" }}

{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}

{{- if  and (has .Values.global.deploymentMode $validDeploymentModes) (ne .Values.global.deploymentMode "ClusterPreferred") }}
  ipFamilyPolicy: SingleStack
  ipFamilies:
  {{- if or (eq .Values.global.deploymentMode "IPv4") (eq .Values.global.deploymentMode "IPv4_IPv6") }}
  - IPv4
  {{- else }}
  - IPv6
  {{- end }}
{{- end }}

{{- end }}

{{/*--------------------DualStack: Deployment Mode------------------------------------------------*/}}
{{- define "dualStack.deploymentMode" }}
{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}
{{- if has .Values.global.deploymentMode $validDeploymentModes }}
{{- .Values.global.deploymentMode }}
{{- else }}
{{- "ClusterPreferred" }}
{{- end}}
{{- end }}

