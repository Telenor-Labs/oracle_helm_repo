{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "nrf-client.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "nrf-client.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "nrf-client.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*--------------------CustomExtension labels for all kubernetes resources-----------------------------------------------------------*/}}
{{- define "custom.extensions.labels.allResources" -}}
{{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
{{- range $key, $value := $global_allResources_labels }}
{{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
{{- end }}
{{- end -}}

{{/*-----------Labels for All kubernetes resources-----------------*/}}
{{- define "labels.allResources" -}}
{{- include "custom.extensions.labels.allResources" . }}
{{- include "engineering.labels" . | nindent 4 }}
{{- end -}}

{{/*-----------Annotations for All kubernetes resources-----------------*/}}
{{- define "annotations.allResources" -}}
{{- include "custom.extensions.annotations.allResources" . }}
{{- include "engineering.annotations" . | nindent 4 }}
{{- end -}}

{{/*--------------------CustomExtension annotations for all kubernetes resources-----------------------------------------------------------*/}}
{{- define "custom.extensions.annotations.allResources" -}}
{{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
{{- range $key, $value := $global_allResources_annotations }}
{{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
{{- end }}
{{- end -}}

{{/*--------------------Horizontal Pod Autoscaler Name------------------------------------------------------------*/}}
{{- define "hpautoscaler.fullname" -}}
{{ .Release.Name | trunc 63 | trimSuffix "-" -}}-{{- .Chart.Name }}
{{- end -}}

{{/*--------------------Deployment Name---------------------------------------------------------------------------*/}}
{{- define "deployment.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*--------------------Service FullName----------------------------------------------------------------------*/}}
{{- define "service.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*--------------------Common Tolerations----------------------------------------------------------------------*/}}
{{- define "ocnf.tolerations" }}
 {{- $localTolerationsSetting := .Values.tolerationsSetting | default "USE_GLOBAL_VALUE" }}
 {{- $globalTolerationsSetting := .Values.global.tolerationsSetting | default "DISABLED" }}
 {{- $tolerations := "" }}

 {{- if (eq $localTolerationsSetting "ENABLED") }}
   {{- $tolerations =  .Values.tolerations }}
 {{- else if (eq $localTolerationsSetting "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalTolerationsSetting "ENABLED")}}
     {{- $tolerations = .Values.global.tolerations }}
   {{- end }}
 {{- end }}

 {{- if $tolerations }}
{{- toYaml $tolerations }}
 {{- end }}
{{- end }}

{{/*-------------------- Persistent configuration --------------------------------------------------------------------*/}}
{{- define "getConfigValue" -}}
 {{- $myDict := dict -}}
 {{- $dot := index . 0 -}}
 {{- $value := "" -}}
  {{- $parts := split "\n" $dot.Values.configmapApplicationConfig.profile -}}
  {{- range $key, $val2 := $parts -}}
    {{- $val2 := ($val2 | trim ) -}}
    {{- $keyVal := split "=" $val2 -}}
    {{- $_ := set $myDict $keyVal._0 $keyVal._1 -}}
  {{- end -}}
  {{- $key := index . 1 -}}
  {{- $value := pluck $key $myDict | first -}}
  {{- printf "%s" $value -}}
{{- end -}}

{{/*--------------------Common NodeSelector----------------------------------------------------------------------*/}}
{{- define "ocnf.nodeselector" }}
 {{- $localNodeSelection := .Values.nodeSelection | default "USE_GLOBAL_VALUE" }}
 {{- $globalNodeSelection := .Values.global.nodeSelection | default "DISABLED" }}
 {{- $nodeselector := "" }}

 {{- if (eq $localNodeSelection "ENABLED") }}
   {{- $nodeselector =  .Values.nodeSelector }}
 {{- else if (eq $localNodeSelection "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalNodeSelection "ENABLED")}}
     {{- $nodeselector = .Values.global.nodeSelector }}
   {{- end }}
 {{- end }}

 {{- if $nodeselector }}
{{- toYaml $nodeselector }}
 {{- end }}
{{- end }}

{{/*--------------------Extra Exclude in/out Bound Ports------------------------------------------------------------*/}}
{{- define "istio-exclude-ports" -}}
{{- if .Values.istioExcludePorts -}}
{{ .Values.cacheServicePortStart }}, {{ .Values.cacheServicePortEnd }}, {{ .Values.cacheServiceLivenessPort }}, {{ .Values.istioExcludePorts }}
{{- else -}}
{{ .Values.cacheServicePortStart }}, {{ .Values.cacheServicePortEnd }}, {{ .Values.cacheServiceLivenessPort }}
{{- end -}}
{{- end -}}

{{/*--------------------------     Template function for injecting Debug Container   ---------------------*/}}
{{- define "extraContainers" -}}
  {{- if (eq .Values.extraContainers "ENABLED") -}}
    {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}}
    {{- if (eq .Values.global.extraContainers "ENABLED") -}}
      {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*-----------------  Template function for injecting Extra Volume for Debug Container -----------------*/}}
{{- define "extraVolumes" -}}
  {{- if (eq .Values.extraContainers "ENABLED") -}}
    {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}}
    {{- if (eq .Values.global.extraContainers "ENABLED") -}}
      {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*-------------------- Convert gracefulShutdown gracePeriod string to seconds ------------------------------------------------------------*/}}
{{- define "gracefulShutdownPeriodToSeconds" -}}
{{- $gracefulShutdownPeriod := .Values.gracefulShutdown.gracePeriod -}}
{{- if regexMatch "^[0-9]+[m]$" $gracefulShutdownPeriod -}}
{{- mul (trimSuffix "m" $gracefulShutdownPeriod) 60 -}}
{{- else if regexMatch "^[0-9]+[s]$" $gracefulShutdownPeriod -}}
{{- trimSuffix "s" $gracefulShutdownPeriod -}}
{{- else -}}
{{- 30 -}}
{{- end -}}
{{- end -}}

{{/*-------------------- Add constraint on maxJavaStackTraceDepth value can not be less then 10, 0 is allowed --------------------------------*/}}
{{- define "maxJavaStackTraceDepth" -}}
{{- $depth := (.Values.logging.maxJavaStackTraceDepth | int) -}}
{{- if eq $depth 0 -}}
  {{- 0 | quote -}}
{{- else if lt $depth 10 -}}
  {{- 10 | quote -}}
{{- else -}}
  {{- $depth | quote -}}
{{- end -}}
{{- end -}}

{{- define "nrf-client.annotations.deployments" -}}
  {{- $istioPorts := include "istio-exclude-ports" . -}}
  {{- $annotations := include "annotations.deployments" . | fromYaml }}
  {{- $defaultIstioAnnotations := dict }}
     {{- $defaultIstioAnnotations = merge $defaultIstioAnnotations (dict "traffic.sidecar.istio.io/excludeOutboundPorts" $istioPorts) -}}
     {{- $defaultIstioAnnotations = merge $defaultIstioAnnotations (dict "traffic.sidecar.istio.io/excludeInboundPorts" $istioPorts) -}}
  {{- $result := merge $annotations $defaultIstioAnnotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
{{- end -}}

{{/*--------------------- Get NRF-Client image ---------------------------------------------------------------------*/}}
{{- define "nrfclient.image" -}}
{{- $imageTag := (.Values.imageTag | not | empty) | ternary .Values.imageTag .Values.global.imageTag -}}
{{- printf "%s/%s:%s" .Values.global.dockerRegistry .Values.image $imageTag -}}
{{- end -}}

{{/*--------------------- Job fullname -----------------------------------------------------------------------------*/}}
{{- define "job.fullname" -}}
{{- printf "%s-%s" .fullname .alias | trunc 63 | trimPrefix "-"| trimSuffix "-" -}}
{{- end -}}

{{/*--------------------- Expand the job fullname of the container -------------------------------------------------*/}}
{{- define "job.container.fullname" -}}
{{- printf "%s-%s-%s-%s" .prefix .fullname .alias .suffix | trunc 63 | trimPrefix "-" | trimSuffix "-" -}}
{{- end -}}

{{/*--------------------- Collect service data in an object ------------------------------------*/}}
{{- define "service.data" -}}
{{- $prefix := include "getprefix" . -}}
{{- $suffix := include "getsuffix" . -}}
{{- $fullname := include "service.fullname" . -}}
{{- $serviceData := dict "prefix" $prefix "suffix" $suffix "fullname" $fullname -}}
{{- mustToJson $serviceData -}}
{{- end -}}

{{/*----------------Nrf-Client NodeSelector----------------------------------------------------------------------*/}}
{{- define "nrfclient.nodeSelector" -}}
  {{- $helmBasedConfigurationNodeSelectorApiVersion:= .Values.helmBasedConfigurationNodeSelectorApiVersion | default "v1" -}}
  {{- if (eq $helmBasedConfigurationNodeSelectorApiVersion "v2") -}}
nodeSelector: {{ include "ocnf.nodeselector" . | nindent 2 -}}
  {{- else if $.Values.global.deploymentNrfClientService.nodeSelectorEnabled -}}
nodeSelector:
  {{ $.Values.global.deploymentNrfClientService.nodeSelectorKey }}: {{ $.Values.global.deploymentNrfClientService.nodeSelectorValue }}
  {{- end -}}
{{- end -}}
