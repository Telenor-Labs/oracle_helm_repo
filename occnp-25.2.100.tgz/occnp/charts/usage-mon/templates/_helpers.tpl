Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "usage-mon.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{- define "service-prefix" -}}
{{- if .Values.global.nfName -}}
{{- printf "%s-%s" .Release.Name .Values.global.nfName | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-deployment-name" -}}
{{- printf "%s-%s" .Release.Name "usage-mon" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-hpa-name" -}}
{{- printf "%s-%s" .Release.Name "usage-mon-hpa" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-name" -}}
{{- printf "%s-%s" (include "service-prefix" .) "usage-mon" | trunc 63 | trimSuffix "-" -}}
{{- end -}}


{{/*-------------------get prefix.-------------------------------------------------------------*/}}
{{- define "getprefix" -}}
{{  default "" .Values.global.k8sResource.container.prefix | lower }}
{{- end -}}

{{/*-------------------getsuffix.-------------------------------------------------------------*/}}
{{- define "getsuffix" -}}
{{  default "" .Values.global.k8sResource.container.suffix | lower }}
{{- end -}}

{{/*--------------------Expand the name of the chart.-------------------------------------------------------------*/}}
{{- define "chart.fullname" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}


{{/*--------------------Create chart name and version as used by the chart label.---------------------------------*/}}
{{- define "chart.fullnameandversion" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Expand the name of the container.-------------------------------------------------------------*/}}
{{- define "container.fullname" -}}
{{- $prefix := default "" .Values.global.k8sResource.container.prefix | lower -}}
{{- $suffix := default "" .Values.global.k8sResource.container.suffix | lower -}}
{{- printf "%s-%s-%s" $prefix (include "chart.fullname" . ) $suffix | trunc 63 | trimPrefix "-"|trimSuffix "-" -}}
{{- end -}}

{{/*--------------------Engineering Labels common for all microservices--------------------------------------------*/}}
{{- define "engineering.labels" -}}
{{- end -}}

{{/*--------------------Engineering Annotations common for all microservices---------------------------------------*/}}
{{- define "engineering.annotations" -}}
{{- end -}}

{{- define "factory.labels" -}}
  {{- range $key, $value := $.Values.global.customExtension.factoryLabelTemplates }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ tpl $value $ }}
  {{- end }}
{{- end -}}

{{- define "factory.annotations" -}}
  {{- range $key, $value := $.Values.global.customExtension.factoryAnnotationTemplates }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ tpl $value $ }}
  {{- end }}
{{- end -}}

{{- define "labels.services" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- $global_services_labels := .Values.global.customExtension.nonlbServices.labels -}}
  {{- if .Values.useLbLabelsAndAnnotations -}} 
     {{- $global_services_labels := .Values.global.customExtension.lbServices.labels -}}
  {{- end -}}
  {{- $service_specific_labels := .Values.service.customExtension.labels -}}
  {{- $result := dict }}
  {{- $result := merge $result $service_specific_labels }}
  {{- $result := merge $result $global_services_labels }}
  {{- $result := merge $result $global_allResources_labels }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
  {{- include "engineering.labels" . | nindent 4 }}
  {{- include "factory.labels" . }}
{{- end -}}

{{- define "labels.deployments" -}}
  {{- $global_allResources_labels := .Values.global.customExtension.allResources.labels -}}
  {{- $global_deployment_labels := .Values.global.customExtension.nonlbDeployments.labels -}}
  {{- if .Values.useLbLabelsAndAnnotations }} 
    {{- $global_deployment_labels := .Values.global.customExtension.lbDeployments.labels }}
  {{- end }}
  {{- $deployment_specific_labels := .Values.deployment.customExtension.labels -}}
  {{- $result := dict }}
  {{- $result := merge $result $deployment_specific_labels }}
  {{- $result := merge $result $global_deployment_labels }}
  {{- $result := merge $result $global_allResources_labels }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
  {{- include "engineering.labels" . | nindent 4 }}
  {{- include "factory.labels" . }}
{{- end -}}

{{- define "annotations.services" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- $global_services_annotations := .Values.global.customExtension.nonlbServices.annotations -}}
  {{- if .Values.useLbLabelsAndAnnotations }} 
    {{- $global_services_annotations := .Values.global.customExtension.lbServices.annotations -}}
  {{- end -}}
  {{- $service_specific_annotations := .Values.service.customExtension.annotations -}}
  {{- $result := dict }}
  {{- $result := merge $result $service_specific_annotations }} 
  {{- $result := merge $result $global_services_annotations }}
  {{- $result := merge $result $global_allResources_annotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
  {{- include "engineering.annotations" . | nindent 4 }}
  {{- include "factory.annotations" . }}
{{- end -}}

{{- define "annotations.deployments" -}}
  {{- $global_allResources_annotations := .Values.global.customExtension.allResources.annotations -}}
  {{- $global_deployment_annotations := .Values.global.customExtension.nonlbDeployments.annotations -}}
  {{- if .Values.useLbLabelsAndAnnotations }} 
    {{- $global_deployment_annotations := .Values.global.customExtension.lbDeployments.annotations -}}
  {{- end -}}
  {{- $deployment_specific_annotations := .Values.deployment.customExtension.annotations -}}
  {{- $result := dict }}
  {{- $result := merge $result $deployment_specific_annotations  }}
  {{- $result := merge $result $global_deployment_annotations }}
  {{- $result := merge $result $global_allResources_annotations }}
  {{- range $key, $value := $result }}
    {{- $key | toYaml | trimSuffix "\n" | nindent 4 }}: {{ $value | trimSuffix "\n" | quote }}
  {{- end }}
  {{- include "engineering.annotations" . | nindent 4 }}
  {{- include "factory.annotations" . }}
{{- end -}}

{{- define "usage-mon-hook-name-pre-install" -}}
{{- printf "%s-%s-%s" .Release.Name "usage-mon" "pre-install" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-hook-name-post-install" -}}
{{- printf "%s-%s-%s" .Release.Name "usage-mon" "post-install" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-hook-name-pre-upgrade" -}}
{{- printf "%s-%s-%s" .Release.Name "usage-mon" "pre-upgrade" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-hook-name-post-upgrade" -}}
{{- printf "%s-%s-%s" .Release.Name "usage-mon" "post-upgrade" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-hook-name-pre-rollback" -}}
{{- printf "%s-%s-%s" .Release.Name "usage-mon" "pre-rollback" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-hook-name-post-rollback" -}}
{{- printf "%s-%s-%s" .Release.Name "usage-mon" "post-rollback" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-hook-name-pre-delete" -}}
{{- printf "%s-%s-%s" .Release.Name "usage-mon" "pre-delete" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "usage-mon-hook-name-post-delete" -}}
{{- printf "%s-%s-%s" .Release.Name "usage-mon" "post-delete" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "config-server-container" -}}
{{- printf "%s-%s-%s" .Release.Name .Values.global.configServerFullNameOverride "hook-container" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*--------------------------Ephemeral Storage-------------------------------------------------------------*/}}
{{- define "usage-mon-ephemeral-storage-request" -}}
 {{- div (mul (add .Values.global.logStorage .Values.global.crictlStorage) 11) 10 -}}Mi
{{- end -}}

{{/*--------------------Common Service Account Name---------------------------------------------------------------*/}}
{{- define "ocnf.serviceaccount" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}-serviceaccount
{{- end -}}


{{/*--------------------------------------Debug Tool Container---------------------------------------------------*/}}
{{- define "extraContainers" -}} 
  {{- if (eq .Values.extraContainers "ENABLED") -}} 
    {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}} 
    {{- if (eq .Values.global.extraContainers "ENABLED") -}} 
      {{- tpl (default .Values.global.extraContainersTpl .Values.extraContainersTpl) . }}
    {{- end -}} 
  {{- end -}} 
{{- end -}} 

{{- define "extraVolumes" -}}
  {{- if (eq .Values.extraContainers "ENABLED") -}}
    {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
  {{- else if (eq .Values.extraContainers "USE_GLOBAL_VALUE") -}}
    {{- if (eq .Values.global.extraContainers "ENABLED") -}}
      {{- tpl (default .Values.global.extraContainersVolumesTpl .Values.extraContainersVolumesTpl) . }}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*--------------------Common NodeSelector----------------------------------------------------------------------*/}}
{{- define "ocnf.nodeselector" }}
 {{- $localNodeSelection := .Values.nodeSelection | default "USE_GLOBAL_VALUE" }}
 {{- $globalNodeSelection := .Values.global.nodeSelection | default "DISABLED" }}
 {{- $nodeselector := "" }}

 {{- if (eq $localNodeSelection "ENABLED") }}
   {{- $nodeselector =  .Values.nodeSelector }}
 {{- else if (eq $localNodeSelection "USE_GLOBAL_VALUE") }}
   {{- if (eq $globalNodeSelection "ENABLED")}}
     {{- $nodeselector = .Values.global.nodeSelector }}
   {{- end }}
 {{- end }}

 {{- if $nodeselector }}
{{- toYaml $nodeselector }}
 {{- end }}
{{- end }}

{{/*---------------------DualStack: ipFamily config-----------------------------------------------------------*/}}
{{- define "dualStack.usageMon.ipFamilies" }}

{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}

{{- if  and (has .Values.global.deploymentMode $validDeploymentModes) (ne .Values.global.deploymentMode "ClusterPreferred") }}
  ipFamilyPolicy: SingleStack
  ipFamilies:
  {{- if or (eq .Values.global.deploymentMode "IPv4") (eq .Values.global.deploymentMode "IPv4_IPv6") }}
  - IPv4
  {{- else }}
  - IPv6
  {{- end }}
{{- end }}

{{- end }}

{{/*--------------------DualStack: Deployment Mode------------------------------------------------*/}}
{{- define "dualStack.deploymentMode" }}
{{- $validDeploymentModes := list "IPv4" "IPv6" "IPv4_IPv6" "IPv6_IPv4" "ClusterPreferred" }}
{{- if has .Values.global.deploymentMode $validDeploymentModes }}
{{- .Values.global.deploymentMode }}
{{- else }}
{{- "ClusterPreferred" }}
{{- end}}
{{- end }}