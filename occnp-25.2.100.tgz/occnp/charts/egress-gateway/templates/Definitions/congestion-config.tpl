{{/*----------------------------------congestion-configuration Section Start------------------------------------*/}}
{{ include "validate-congestion-config" . -}}
{{- define "congestion-config" -}}
{{- $congestionConfigJson := tpl ( .Files.Get "config/congestionConfig.json" ) . }}
congestionConfig:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "congestionConfig" .Values.nfSpecificConfig.featureList) (  $congestionConfigJson) }}
{{ $congestionConfigJson | indent 2 }}
{{- else if eq .Values.congestionConfigMode "REST" }}
  refreshInterval: {{ .Values.congestionConfig.refreshInterval }}
  {{- if gt (len .Values.congestionConfig.levels) 0 }}
  levels:
  {{- range .Values.congestionConfig.levels }}
  - value: {{ .value }}
    name: {{ .name }}
    resources:
    {{- range .resources }}
    - name: {{ .name }}
      {{- if hasKey . "onset" }}
      onset: {{ .onset }}
      {{- end }}
      {{- if hasKey . "abatement" }}
      abatement: {{ .abatement }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- else }}
  levels: []
  {{- end }}
{{- else }}
  refreshInterval: {{ .Values.congestionConfig.refreshInterval }}
  {{- if gt (len .Values.congestionConfig.levels) 0 }}
  levels:
  {{- range .Values.congestionConfig.levels }}
  - value: {{ .value }}
    name: {{ .name }}
    resources:
    {{- range .resources }}
    - name: {{ .name }}
      {{- if hasKey . "onset" }}
      onset: {{ .onset }}
      {{- end }}
      {{- if hasKey . "abatement" }}
      abatement: {{ .abatement }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- else }}
  levels: []
  {{- end }}
{{- end }}
{{- end }}
{{- end }}
{{/*-----------------------------------congestion-configuration Section End-------------------------------------*/}}
