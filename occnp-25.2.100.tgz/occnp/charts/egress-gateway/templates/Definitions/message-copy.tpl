{{/*----------------------------------Message Copy------------------------------------*/}}
{{- if .Values.messageCopy.enabled }}
{{ include "validate-message-copy-config" . -}}
{{- end }}