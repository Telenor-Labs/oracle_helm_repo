{{/*----------------------------------Custom Header------------------------------------*/}}
{{- if or (eq (toString .Values.routeConfigMode) "HELM")  (and (eq (toString .Values.routeConfigMode) "REST") (eq (toString .Values.convertHelmRoutesToREST) "true") )}}
{{ include "validate-custom-validator-config" . -}}
{{- end }}