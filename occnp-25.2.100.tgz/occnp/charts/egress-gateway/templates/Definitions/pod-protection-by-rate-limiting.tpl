{{/*----------------------------------pod-protection-by-rate-limiting Section Start------------------------------------*/}}
{{- if .Values.podProtectionByRateLimiting.enabled }}
{{ include "validate-pod-protection-by-rate-limiting" . -}}
{{- end }}
{{ include "validatePriorities" . -}}
{{- define "pod-protection-by-rate-limiting" -}}
{{- $podProtectionByRateLimitingJson := tpl ( .Files.Get "config/podProtectionByRateLimiting.json" ) . }}
podProtectionByRateLimiting:
{{- if .Values.nfSpecificConfig }}
{{- if and (.Values.nfSpecificConfig.featureList) (has "podProtectionByRateLimiting" .Values.nfSpecificConfig.featureList) ($podProtectionByRateLimitingJson) }}
{{ $podProtectionByRateLimitingJson | indent 2 }}
{{- else if eq .Values.podProtectionByRLConfigMode "REST" }}
  enabled: {{ .Values.podProtectionByRateLimiting.enabled }}
  fillRate: {{ .Values.podProtectionByRateLimiting.fillRate }}
  {{- if gt (len .Values.podProtectionByRateLimiting.routes) 0 }}
  routes:
  {{- range .Values.podProtectionByRateLimiting.routes}}
    - id: {{ .id}}
      {{- if .routeId }}
      routeId: {{ .routeId }}
      {{- else }}
      methods:
{{ toYaml .methods | indent 8 }}
      path: {{ .path }}
      {{- end }}
      percentage: {{ .percentage }}
      {{- if hasKey . "defaultPriority" }}
      defaultPriority: {{ .defaultPriority }}
      {{- end }}
  {{- end }}
  {{- else }}
  routes: []
  {{- end }}
  errorCodeProfile: {{ .Values.podProtectionByRateLimiting.errorCodeProfile }}
  {{- if gt (len .Values.podProtectionByRateLimiting.deniedRequestActions) 0 }}
  deniedRequestActions:
  {{- range .Values.podProtectionByRateLimiting.deniedRequestActions }}
  - id: {{ .id }}
    {{- if .priority }}
    priority: {{ .priority | quote }}
    {{- end }}
    {{- if hasKey . "congestionLevel" }}
    congestionLevel: {{ .congestionLevel }}
    {{- end }}
    {{- if .action }}
    action: {{ .action }}
    {{- end }}
    {{- if .errorCodeProfile }}
    errorCodeProfile: {{ .errorCodeProfile }}
    {{- end }}
  {{- end }}
  {{- else }}
  deniedRequestActions: []
  {{- end }}
  priorityHeaderName: {{ .Values.podProtectionByRateLimiting.priorityHeaderName }}
  defaultPriority: {{ .Values.podProtectionByRateLimiting.defaultPriority }}
{{- else }}
  enabled: {{ .Values.podProtectionByRateLimiting.enabled }}
  fillRate: {{ .Values.podProtectionByRateLimiting.fillRate }}
  {{- if gt (len .Values.podProtectionByRateLimiting.routes) 0 }}
  routes:
  {{- range .Values.podProtectionByRateLimiting.routes}}
    - id: {{ .id}}
      {{- if .routeId }}
      routeId: {{ .routeId }}
      {{- else }}
      methods:
{{ toYaml .methods | indent 8 }}
      path: {{ .path }}
      {{- end }}
      percentage: {{ .percentage }}
      {{- if hasKey . "defaultPriority" }}
      defaultPriority: {{ .defaultPriority }}
      {{- end }}
  {{- end }}
  {{- else }}
  routes: []
  {{- end }}
  errorCodeProfile: {{ .Values.podProtectionByRateLimiting.errorCodeProfile }}
  {{- if gt (len .Values.podProtectionByRateLimiting.deniedRequestActions) 0 }}
  deniedRequestActions:
  {{- range .Values.podProtectionByRateLimiting.deniedRequestActions }}
  - id: {{ .id }}
    {{- if .priority }}
    priority: {{ .priority | quote }}
    {{- end }}
    {{- if hasKey . "congestionLevel" }}
    congestionLevel: {{ .congestionLevel }}
    {{- end }}
    {{- if .action }}
    action: {{ .action }}
    {{- end }}
    {{- if .errorCodeProfile }}
    errorCodeProfile: {{ .errorCodeProfile }}
    {{- end }}
  {{- end }}
  {{- else }}
  deniedRequestActions: []
  {{- end }}
  priorityHeaderName: {{ .Values.podProtectionByRateLimiting.priorityHeaderName }}
  defaultPriority: {{ .Values.podProtectionByRateLimiting.defaultPriority }}
 {{- end }}
{{- end }}
{{- end }}
{{/*-----------------------------------pod-protection-by-rate-limiting Section End-------------------------------------*/}}
