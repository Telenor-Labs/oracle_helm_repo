{{/*------------------- Message Copy -------------------------------------------------------------*/}}
{{- define "validate-message-copy-config" }}
  {{- with .Values.messageCopy }}
  {{- if .enabled }}
    {{/* Validate maxBlockMs */}}
    {{- $maxBlockMs := .maxBlockMs | int64 }}
    {{- if not (and (ge $maxBlockMs 0) (le $maxBlockMs 9223372036854775807)) }}
      {{- fail (printf "Invalid maxBlockMs value %s. It must be between 0 and 9223372036854775807 (Long.MAX_VALUE)." (.maxBlockMs | quote)) }}
    {{- end }}

    {{/* Validate deliveryTimeoutMs */}}
    {{- $deliveryTimeoutMs := .deliveryTimeoutMs | int }}
    {{- if not (and (ge $deliveryTimeoutMs 0) (le $deliveryTimeoutMs 2147483647)) }}
      {{- fail (printf "Invalid deliveryTimeoutMs value %s. It must be between 0 and 2147483647 (Integer.MAX_VALUE)." (.deliveryTimeoutMs | quote)) }}
    {{- end }}

    {{/* Validate bufferMemoryBytes */}}
    {{- $bufferMemoryBytes := .bufferMemoryBytes | int64 }}
    {{- if not (and (ge $bufferMemoryBytes 0) (le $bufferMemoryBytes 9223372036854775807)) }}
      {{- fail (printf "Invalid bufferMemoryBytes value %s. It must be between 0 and 9223372036854775807 (Long.MAX_VALUE)." (.bufferMemoryBytes | quote)) }}
    {{- end }}

    {{/* Validate batchSizeBytes */}}
    {{- $batchSizeBytes := .batchSizeBytes | int }}
    {{- if not (and (ge $batchSizeBytes 0) (le $batchSizeBytes 2147483647)) }}
      {{- fail (printf "Invalid batchSizeBytes value %s. It must be between 0 and 2147483647 (Integer.MAX_VALUE)." (.batchSizeBytes | quote)) }}
    {{- end }}

    {{/* Validate lingerMs */}}
    {{- $lingerMs := .lingerMs | int }}
    {{- if not (and (ge $lingerMs 0) (le $lingerMs 2147483647)) }}
      {{- fail (printf "Invalid lingerMs value %s. It must be between 0 and 2147483647 (Integer.MAX_VALUE)." (.lingerMs | quote)) }}
    {{- end }}

    {{/* Validate sendBufferBytes */}}
    {{- $sendBufferBytes := .sendBufferBytes | int }}
    {{- if not (and (ge $sendBufferBytes -1) (le $sendBufferBytes 2147483647)) }}
      {{- fail (printf "Invalid sendBufferBytes value %s. It must be between -1 and 2147483647 (Integer.MAX_VALUE)." (.sendBufferBytes | quote)) }}
    {{- end }}
  {{- end }}
  {{- end }}
{{- end }}