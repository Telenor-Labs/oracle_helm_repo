{{/*------------------- Custom Validator -------------------------------------------------------------*/}}
{{- define "validate-custom-validator-config" }}
  {{- range .Values.routesConfig }}
  
    {{/* Validate CustomReqHeaderEntryFilter */}}
    {{- if .filterNameReqEntry }}
    {{- if .filterNameReqEntry.args.headers }}
        {{- range .filterNameReqEntry.args.headers }}
            {{- range .headersList }}
                {{- if or (not .defaultVal) (eq (toString .defaultVal) "null") }}
                  {{- fail (printf "defaultVal is null") }}
                {{- end }}
            {{- end }}
        {{- end }}
    {{- end }}   
    {{- end }}

    {{/* Validate CustomReqHeaderExitFilter */}}
    {{- if .filterNameReqExit }}
    {{- if .filterNameReqExit.args.headers }}
        {{- range .filterNameReqExit.args.headers }}
            {{- range .headersList }}
                {{- if or (not .defaultVal) (eq (toString .defaultVal) "null") }}
                  {{- fail (printf "defaultVal is null") }}
                {{- end }}
            {{- end }}
        {{- end }}
    {{- end }}
    {{- end }}

    {{/* Validate CustomResHeaderEntryFilter */}}
    {{- if .filterNameResEntry }}
    {{- if .filterNameResEntry.args.headers }}
        {{- range .filterNameResEntry.args.headers }}
            {{- range .headersList }}
                {{- if or (not .defaultVal) (eq (toString .defaultVal) "null") }}
                  {{- fail (printf "defaultVal is null") }}
                {{- end }}
            {{- end }}
        {{- end }}
    {{- end }}    
    {{- end }}

    {{/* Validate CustomResHeaderExitFilter */}}
    {{- if .filterNameResExit }}
    {{- if .filterNameResExit.args.headers }}
        {{- range .filterNameResExit.args.headers }}
            {{- range .headersList }}
                {{- if or (not .defaultVal) (eq (toString .defaultVal) "null") }}
                  {{- fail (printf "defaultVal is null") }}
                {{- end }}
            {{- end }}
        {{- end }}
    {{- end }}    
    {{- end }}

  {{- end }}
{{- end }}