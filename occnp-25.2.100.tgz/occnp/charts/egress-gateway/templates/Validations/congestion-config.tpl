{{- define "validate-congestion-config" }}

    {{/* Validate refreshInterval */}}
    {{- if not (hasKey .Values.congestionConfig "refreshInterval") }}
        {{ fail "Missing required parameter: refreshInterval" }}
    {{- end }}

    {{- $possibleRefreshInterval := int .Values.congestionConfig.refreshInterval }}
    {{- if not (and (ge $possibleRefreshInterval 200) (le $possibleRefreshInterval 5000)) }}
        {{ fail (printf "Invalid refreshInterval value %s. It must be between 200 to 5000." (.Values.congestionConfig.refreshInterval | quote)) }}
    {{- end }}

    {{/* To validate that congestionConfigMode value is either HELM or REST */}}
    {{- $possibleCongestionModes := dict "HELM" true "REST" true }}
    {{- if not (hasKey $possibleCongestionModes .Values.congestionConfigMode) }}
        {{ fail (printf "Invalid congestionConfigMode value %s. Supported values are 'HELM' and 'REST'." ($.Values.congestionConfigMode | quote)) }}
    {{- end }}

    {{/* Allowed congestion config level value is CPU */}}
    {{- $possibleResources := dict "CPU" true }}

    {{/* To validate that congestion config level can have maximum of 10 rules */}}
    {{- if gt (len .Values.congestionConfig.levels) 10 }}
        {{ fail "Maximum number of Congestion Control levels exceeded. The maximum allowed is 10." }}
    {{- end }}

    {{- $seenLevels := dict }}
    {{- $prevResources := dict }}
    {{/* Populate resource values of each level in a dictionary, needed for validation of levels. */}}
    {{- range $l := .Values.congestionConfig.levels }}
        {{- range $r := $l.resources }}
            {{- $prevResources := set $prevResources (printf "%s-%s" (toString $l.value) $r.name) $r }}
        {{- end }}
    {{- end }}

    {{- $seenNames := dict }}
    {{- range $level := .Values.congestionConfig.levels }}
        {{- if not (hasKey $level "name") }}
            {{ fail (printf "Congestion level name is missing at level %s" ($level.value | quote)) }}
        {{- end }}

        {{- if eq ($level.name | quote | trim) "" }}
            {{ fail (printf "Congestion level name cannot be empty at level %s" ($level.value | quote)) }}
        {{- end }}

        {{- if hasKey $seenNames ($level.name | quote) }}
            {{ fail (printf "Duplicate congestion level name found: %s" ($level.name|quote) ) }}
        {{- else }}
            {{- $seenNames = set $seenNames ($level.name | quote) true }}
        {{- end }}
    {{- end }}

    {{/* To validate unique, sequential levels inside congestionConfig */}}
    {{- $n := len .Values.congestionConfig.levels }}
    {{- $values := list }}
    {{- range .Values.congestionConfig.levels }}
        {{- $values = append $values .value }}
    {{- end }}
    {{- $uniqueDict := dict }}
    {{- $allDistinct := true }}
    {{- range $value := $values }}
        {{- if hasKey $uniqueDict ($value | quote) }}
            {{- $allDistinct = false }}
        {{- else }}
            {{- $_ := set $uniqueDict ($value | quote) true }}
        {{- end }}
    {{- end }}
    {{- if not $allDistinct }}
        {{- fail "Congestion config level values must be distinct" }}
    {{- end }}

    {{- range $i := until $n }}
        {{- $val := add $i 1 }}
        {{- if not (hasKey $uniqueDict ($val | quote)) }}
            {{ fail "Congestion configuration level values must be consecutive integers starting from 1." }}
        {{- end }}
    {{- end }}

    {{- range $index, $level := .Values.congestionConfig.levels }}
        {{- if hasKey $seenLevels ($level.value | quote) }}
            {{ fail (printf "Duplicate level value found: %s" ($level.value|quote) ) }}
        {{- else }}
            {{- $seenLevels = set $seenLevels ($level.value | quote) true }}
        {{- end }}

        {{- if or (gt (int $level.value) 10) (lt (int $level.value) 1) }}
            {{ fail (printf "Level value must be between 1 and 10. Found %s" ($level.value | quote)) }}
        {{- end }}

        {{- if gt (len $level.resources) (len $possibleResources) }}
            {{ fail (printf "Maximum number of resources type exceeded. Maximum allowed is %s namely %s" (len $possibleResources | quote) (keys $possibleResources | sortAlpha)) }}
        {{- end }}

        {{/* To validate Onset and Abatement values at same congestion config level */}}
        {{- range $resource := $level.resources }}
            {{- if not (hasKey $possibleResources $resource.name) }}
                {{ fail (printf "Resource name must be one of %s. Found '%s'" (keys $possibleResources | sortAlpha) $resource.name) }}
            {{- end }}

            {{- if hasKey $resource "onset" }}
                {{- if (not (regexMatch "^-?[0-9]+$" ($resource.onset | toString))) }}
                    {{- fail (printf "Invalid Onset threshold for %s resource of level %s." $resource.name ($level.value | quote) ) }}
                {{- end }}
                {{- if (lt (int $resource.onset) 0) }}
                    {{- fail (printf "Onset threshold must be greater than or equal to 0. Found: %s onset value %s" $resource.name ($resource.onset | quote)) }}
                {{- end }}

                {{- if and (gt (int $resource.onset) 100) (eq $resource.name "CPU") }}
                    {{- fail (printf "CPU onset threshold must not be more than 100. Found: %s onset value %s" $resource.name ($resource.onset | quote)) }}
                {{- end }}
            {{- else }}
                {{- fail (printf "Onset threshold is missing for %s resource of level %s." $resource.name ($level.value | quote) ) }}
            {{- end }}

            {{- if hasKey $resource "abatement" }}
                {{- if (not (regexMatch "^-?[0-9]+$" ($resource.abatement | toString))) }}
                    {{- fail (printf "Invalid Abatement threshold for %s resource of level %s." $resource.name ($level.value | quote) ) }}
                {{- end }}
                {{- if (lt (int $resource.abatement) 0) }}
                    {{- fail (printf "Abatement threshold must be greater than or equal to 0. Found %s abatement value %s" $resource.name ($resource.abatement | quote)) }}
                {{- end }}

                {{- if and (gt (int $resource.abatement) 100) (eq $resource.name "CPU") }}
                    {{- fail (printf "CPU abatement threshold must not be more than 100. Found: %s abatement value %s" $resource.name ($resource.abatement | quote)) }}
                {{- end }}
            {{- else }}
                {{- if or (ne (int $level.value) 1) (and (eq (int $level.value) 1) (gt (int $resource.onset) 0)) }}
                    {{- fail (printf "Abatement threshold is missing for %s resource of level %s." $resource.name ($level.value | quote) ) }}
                {{- end }}
            {{- end }}

            {{- if and (and (hasKey $resource "onset") (hasKey $resource "abatement")) (le $resource.onset $resource.abatement) }}
                {{- fail (printf "Onset threshold must be greater than abatement threshold. Found: %s onset=%s, abatement=%s at level %s" $resource.name ($resource.onset | quote) ($resource.abatement | quote) ($level.value | quote)) }}
            {{- end }}
        {{- end }}

        {{/* To validate Onset and Abatement values across all Congestion Config levels:
        For a Congestion Resource
        1. The Onset value of a level must always be greater than the Abatement value of the previous level.
        */}}
        {{- if gt (int $level.value) 1 }}
            {{- $prevLevel := index $.Values.congestionConfig.levels (add (int $level.value) -1 ) }}

            {{- range $resource := $level.resources }}
                {{- $prevResource := get $prevResources (printf "%s-%s" (toString (add (int $level.value) -1)) $resource.name) }}

                {{- if and $prevResource (hasKey $prevResource "onset") (hasKey $resource "abatement") (le (int $resource.abatement) (int $prevResource.onset)) }}
                    {{- fail (printf "The abatement value of the %s resource at level %s must be greater than the onset value from the previous level. Found: %s abatement=%s, previous onset=%s" ($resource.name | quote) ($level.value | quote) ($resource.name | quote) ($resource.abatement | quote) ($prevResource.onset | quote)) }}
                {{- end }}
            {{- end }}
        {{- end }}

    {{- end }}

{{- end }}