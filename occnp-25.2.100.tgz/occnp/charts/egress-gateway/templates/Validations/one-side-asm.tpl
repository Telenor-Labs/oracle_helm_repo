{{- define "validate-one-side-asm" }}

{{/* To validate that flag value provided is boolean */}}
{{ include "validateBoolean" (list .Values.intraNfServiceMesh "intraNfServiceMesh")}}
{{ include "validateBoolean" (list .Values.serviceMeshCheck "serviceMeshCheck")}}

{{- end }}

{{- define "validateNonEmptyString" }}
  {{- $value := index . 0 }}
  {{- $name := index . 1 }}
  {{- if eq ($value | quote | trim) "" }}
    {{- fail (printf "Invalid %s: Cannot be empty." $name) }}
  {{- end }}
{{- end }}

{{- define "validateBoolean" }}
  {{- $value := index . 0 }}
  {{- $name := index . 1 }}
  {{- if not (kindIs "bool" $value) }}
    {{- fail (printf "Invalid %s: Must be a boolean." $name) }}
  {{- end }}
{{- end }}