{{- define "validate-pod-protection-by-rate-limiting" -}}
{{/* To validate fillRate is a positive value */}}
{{- if (le (int .Values.podProtectionByRateLimiting.fillRate) 0) }}
    {{- fail "fillRate must be positive value." }}
{{- end }}
{{- $fillRateValue := .Values.podProtectionByRateLimiting.fillRate }}
{{- if not (regexMatch "^[0-9]+$" (toString $fillRateValue)) }}
    {{- fail "fillRate must be integer value." }}
{{- end }}
{{/* To validate bucketAllocation value between 0-1000. This is optional. */}}
{{- if hasKey .Values.podProtectionByRateLimiting "bucketAllocation" }}
    {{- if or (lt (int .Values.podProtectionByRateLimiting.bucketAllocation) 0) (gt (int .Values.podProtectionByRateLimiting.bucketAllocation) 1000) }}
        {{- fail (printf "Invalid bucketAllocation value %s. The bucketAllocation value should be between 0 and 1000" (.Values.podProtectionByRateLimiting.bucketAllocation | quote)) }}
    {{- end }}
{{- end }}
{{- $route := dict }}
{{- $ids := dict }}
{{- $totalPercentage := float64 0 -}}
{{- $routeIds := dict }}
{{- $scgRouteIds := dict }}
{{- $errorCodeProfiles := dict }}
{{/* Store SCG route ids for validation */}}
{{- range .Values.routesConfig }}
        {{- $id := .id }}
        {{- $scgRouteIds = merge $scgRouteIds (dict $id true) }}
    {{- end }}
{{/* Store errorCodeProfiles for validation */}}
{{- range .Values.errorCodeProfiles }}
{{- $name := .name }}
{{- $errorCodeProfiles = merge $errorCodeProfiles (dict $name true) }}
{{- end }}
{{/* To validate errorcodeProfile is valid */}}
{{- $errorcodeProf := .Values.podProtectionByRateLimiting.errorCodeProfile }}
{{- if $errorcodeProf }}
  {{- if not (hasKey $errorCodeProfiles $errorcodeProf) }}
    {{- fail (printf "errorCodeProfile in PodProtection not found in available errorcodeprofiles %s." $errorcodeProf) }}
  {{- end }}
{{- end }}
    {{- range .Values.podProtectionByRateLimiting.routes}}
        {{/* Validation for id */}}
        {{- if (lt (int .id) 1) }}
            {{- fail "id must be a positive integer ."}}
        {{- end }}
        {{/* Validation for id greater than 100 */}}
        {{- if (gt (int .id) 100) }}
            {{- fail (printf "Route id %v is invalid. Id value must be between 1 and 100." .id) }}
        {{- end }}
        {{/* Validation for duplicate id */}}
        {{- $id := .id }}
        {{- $idKey := printf "%s" $id }}
        {{- if hasKey $ids $idKey }}
            {{- fail "duplicate id found in routes"}}
        {{- else }}
            {{- $ids = merge $ids (dict $idKey true) }}
        {{- end }}
        {{- $path := .path }}
        {{- $methods := .methods }}
        {{- $routeId := .routeId }}
        {{- $routeKey := "" }}
        {{- if $routeId }}
        {{- $routeKey = printf "%s" $routeId }}
        {{- if not (hasKey $scgRouteIds $routeId) }}
           {{- fail (printf "Route ID configured not found in gateway routes %s." $routeId) }}
        {{- end }}
        {{- else }}
            {{- $routeKey = printf "%s|%s" $methods $path }}
        {{- end }}
        {{- if hasKey $route $routeKey }}
            {{- fail (printf "Duplicate route detected: %s." $routeKey) }}
        {{- else }}
            {{- $route = merge $route (dict $routeKey true) }}
        {{- end}}

        {{/* To validate defaultPriority value between 0-31. This is optional field within routes */}}
        {{- if hasKey . "defaultPriority" }}
            {{- if not (regexMatch "^[0-9]+$" (toString .defaultPriority)) }}
                {{- fail (printf "Invalid defaultPriority value %s for route id:%s" (.defaultPriority | quote) ($id | quote)) }}
            {{- end }}
            {{- if or (lt (int .defaultPriority) 0) (gt (int .defaultPriority) 31) }}
                {{- fail (printf "Invalid defaultPriority value %s. The defaultPriority value for route id:%s should be between 0 and 31" (.defaultPriority | quote) ($id | quote)) }}
            {{- end }}
        {{- end }}
    {{- end }}
    {{- $uniqueRoutes := dict }}
    {{- range .Values.podProtectionByRateLimiting.routes }}
        {{/* Validation for routeId if present then don't validate paths */}}
        {{- $routeId := .routeId }}
        {{- if $routeId }}
            {{- $path := .path }}
            {{- $methods := .methods }}
            {{- if or ($path) ($methods) }}
                {{ fail (printf "Invalid config podProtectionByRateLimiting: path and methods not required when routeId present routeId %s" $routeId )}}
            {{- end}}
        {{- else }}
            {{/* Validation for paths */}}
            {{- $path := .path }}
            {{- if or (not $path) (eq $path "") }}
                {{ fail "Invalid path: path cannot be null or empty." }}
            {{- end }}
            {{/* Validation for methods */}}
            {{- $allowedMethods := dict "POST" true "PUT" true "PATCH" true "DELETE" true "GET" true "HEAD" true "OPTIONS" true "TRACE" true "CONNECT" true -}}
            {{- $methods := .methods -}}
            {{- if lt (len .methods) 1 }}
                {{ fail "Atleast one method should be configured in RL routes." }}
            {{- end }}
            {{- range $method := $methods -}}
                {{- if not (hasKey $allowedMethods $method) }}
                    {{- fail (printf "Invalid method found : %s. Allowed values are POST, PUT, PATCH, DELETE, GET." $method) }}
                {{- end }}
            {{- end }}
            {{- $id := .id }}
            {{- $uniqueMethods := list }}
            {{- range $method := $methods -}}
                {{- range $uMethod := $uniqueMethods -}}
                    {{- if eq $method $uMethod }}
                        {{- fail (printf "Duplicate method found : %s at route with id : %d." $method (int $id)) }}
                    {{- end }}
                {{- end }}
                {{- $uniqueMethods = append $uniqueMethods $method }}
            {{- end }}
            {{- if hasKey $uniqueRoutes $path }}
                {{- $uMethodSet := index $uniqueRoutes $path }}
                {{- range $method := $methods -}}
                    {{- range $uMethod := $uMethodSet -}}
                        {{- if eq $method $uMethod }}
                            {{- fail (printf "Duplicate method found across routes : %s, path: %s" $method $path) }}
                        {{- end }}
                    {{- end }}
                    {{- $uMethodSet = append $uMethodSet $method }}
                {{- end }}
                {{- $_ := set $uniqueRoutes $path $uMethodSet }}
            {{- else }}
                {{- $_ := set $uniqueRoutes $path $uniqueMethods }}
            {{- end }}
        {{- end }}

        {{/* To validate route percentage cannot be 0 or negative */}}
        {{- $perc := float64 .percentage }}
        {{- $limit := float64 0.1 -}}
        {{- if lt $perc $limit }}
            {{- fail "route percentages must be greater than or equal to  0.1" }}
        {{- end }}
        {{- $totalPercentage = addf $totalPercentage $perc -}}
    {{- end}}
    {{/* To validation total route percentages does not exceed 100  */}}
    {{- $limit := float64 100.0 -}}
    {{- if gt $totalPercentage $limit }}
        {{- fail "Invalid configuration: The sum of all percentages cannot exceed 100." -}}
    {{- end }}

    {{/* To validate mandatory field defaultPriority and its value in the range 0-31 under podProtectionByRateLimiting */}}
    {{- if not (hasKey .Values.podProtectionByRateLimiting "defaultPriority") }}
        {{- fail "defaultPriority is mandatory under podProtectionByRateLimiting" }}
    {{- else }}
        {{- $defaultPriority := .Values.podProtectionByRateLimiting.defaultPriority }}
        {{- if not (regexMatch "^[0-9]+$" (toString $defaultPriority)) }}
            {{- fail "Invalid defaultPriority value in podProtectionByRateLimiting" }}
        {{- end }}
        {{- if or (lt (int $defaultPriority) 0) (gt (int $defaultPriority) 31) }}
            {{- fail (printf "Invalid defaultPriority value %s. The defaultPriority value under podProtectionByRateLimiting should be between 0 and 31" ($defaultPriority | quote)) }}
        {{- end }}
    {{- end }}

    {{/* To validate mandatory field priorityHeaderName and its value cannot be empty under podProtectionByRateLimiting */}}
    {{- if not (hasKey .Values.podProtectionByRateLimiting "priorityHeaderName") }}
        {{- fail "priorityHeaderName is mandatory under podProtectionByRateLimiting" }}
    {{- else }}
        {{- $priorityHeaderName := .Values.podProtectionByRateLimiting.priorityHeaderName }}
        {{- if not $priorityHeaderName }}
            {{- fail "priorityHeaderName under podProtectionByRateLimiting cannot be empty" }}
        {{- end }}
    {{- end }}

    {{/* To validate that all ID values inside deniedRequestActions are unique and that priority values are within the 0-31 range, inclusive. */}}
    {{/* To validate congestion level maps to the valid level defined under congestionConfig. */}}
    {{- $validCongestionLevels := dict }}
    {{- $validCongestionLevels = merge $validCongestionLevels (dict "0" true) }}
    {{- if .Values.congestionConfig }}
        {{- if .Values.congestionConfig.levels }}
            {{- range .Values.congestionConfig.levels }}
                {{- if .value }}
                    {{- $levelValue := .value | toString }}
                    {{- $validCongestionLevels = merge $validCongestionLevels (dict $levelValue true) }}
                {{- else }}
                    {{- fail "congestionConfig.levels.value cannot be null, empty or 0" }}
                {{- end }}
            {{- end }}
        {{- else }}
            {{- fail "congestionConfig.levels cannot be null or empty" }}
        {{- end }}
    {{- else }}
        {{- fail "congestionConfig cannot be null or empty" }}
    {{- end }}
    {{- $draIds := dict }}
    {{- $possibleActions := dict "REJECT" true "CONTINUE" true }}
    {{- range .Values.podProtectionByRateLimiting.deniedRequestActions }}
        {{- $id := .id }}
        {{- $priority := .priority }}
        {{- $action := .action }}
        {{- $errorCodeProfile := .errorCodeProfile }}
        {{- $idKey := printf "%d" $id }}
        {{- if not $action }}
            {{- fail "Action field is missing in deniedRequestActions. Action must be either 'REJECT' or 'CONTINUE'." }}
        {{- else }}
            {{- if not (hasKey $possibleActions $action) }}
                {{- fail (printf "Invalid deniedRequestActions.action value %s. Supported values are 'REJECT' and 'CONTINUE'." $action) }}
            {{- end }}
        {{- end }}
        {{- if .errorCodeProfile }}
              {{- $errorcodeProf1 := .errorCodeProfile }}
              {{- if not (hasKey $errorCodeProfiles $errorcodeProf1) }}
                {{- fail (printf "errorCodeProfile in PodProtection deniedRequestAction not found in available errorcodeprofiles %s." $errorcodeProf1) }}
              {{- end }}
            {{- end }}
        {{- if hasKey $draIds $idKey }}
            {{- fail "Duplicate id found in deniedRequestActions" }}
        {{- else }}
            {{- $draIds = merge $draIds (dict $idKey true) }}
        {{- end }}
        {{- if (lt (int $id) 1) }}
            {{- fail "id must be a positive integer ."}}
        {{- end }}
        {{- if (hasKey . "congestionLevel") }}
            {{- $congestionLevelStr := .congestionLevel | toString }}
            {{- if eq $congestionLevelStr "" }}
                {{- fail (printf "Invalid congestionLevel value %s in deniedRequestActions." $congestionLevelStr) }}
            {{- else if not (hasKey $validCongestionLevels $congestionLevelStr) }}
                {{- fail (printf "Invalid congestionLevel value %s in deniedRequestActions." $congestionLevelStr) }}
            {{- end }}
        {{- end }}

        {{/*
          Validate that errorCodeProfile is present only when action is REJECT,
          and absent when action is CONTINUE.
        */}}
        {{- if eq $action "CONTINUE" }}
            {{- if $errorCodeProfile }}
                {{- fail "errorCodeProfile should not be present when action is CONTINUE" }}
            {{- end }}
        {{- else if eq $action "REJECT" }}
            {{- if not $errorCodeProfile }}
                {{- fail "errorCodeProfile is required when action is REJECT" }}
            {{- end }}
        {{- end }}
    {{- end }}
{{- end }}


{{- define "validatePriorities" -}}
{{- $drActions := .Values.podProtectionByRateLimiting.deniedRequestActions -}}
{{- $ranges := list -}}
{{- $rangesPerCongestionLevel := dict -}}

{{- range $deniedRequestAction := $drActions }}
    {{- $congestionLevel := ($deniedRequestAction.congestionLevel | quote) | default "default" }}
    {{- if $deniedRequestAction.priority }}
    {{- if contains "-" $deniedRequestAction.priority }}
        {{- $parts := splitList "-" $deniedRequestAction.priority }}
        {{- $partOne := (index $parts 0) }}
        {{- $partTwo := (index $parts 1) }}
        {{- if or (not (regexMatch "^-?[0-9]+$" ($partOne | toString))) (not (regexMatch "^-?[0-9]+$" ($partTwo | toString))) }}
            {{- fail "Invalid priority value in deniedRequestActions" }}
        {{- end }}
        {{- if or (and (eq (len $parts) 2) (not (index $parts 0))) (gt (len $parts) 2) }}
            {{- fail (printf "Invalid priority value in deniedRequestActions value: priority=%s. Allowed range is 0-31" $deniedRequestAction.priority) }}
        {{- end }}
        {{- $start := int (index $parts 0) }}
        {{- $end := int (index $parts 1) }}
        {{- if or (lt $start 0) (gt $start 31) (lt $end 0) (gt $end 31) }}
          {{- fail (print "Priority value out of range in deniedRequestActions: Allowed range is 0-31") }}
        {{- end }}
        {{- $val := get $rangesPerCongestionLevel (toString $congestionLevel) | default list }}
        {{- $_ := set $rangesPerCongestionLevel (toString $congestionLevel) (( append $val (dict "start" $start "end" $end))) }}
    {{- else }}
        {{- if (not (regexMatch "^-?[0-9]+$" ($deniedRequestAction.priority | toString))) }}
            {{- fail "Invalid priority value in deniedRequestActions" }}
        {{- end }}
        {{- $value := int $deniedRequestAction.priority }}
        {{- if or (lt $value 0) (gt $value 31) }}
          {{- fail (print "Priority value out of range in deniedRequestActions: Allowed range is 0-31") }}
        {{- end }}
        {{- $val := get $rangesPerCongestionLevel (toString $congestionLevel) | default list }}
        {{- $_ := set $rangesPerCongestionLevel (toString $congestionLevel) (( append $val (dict "start" $value "end" $value))) }}
    {{- end }}
    {{- end }}
{{- end }}

{{- range $congestionLevel, $ranges := $rangesPerCongestionLevel }}
    {{- range $i, $range1 := $ranges }}
        {{- range $j, $range2 := $ranges }}
            {{- if and (ne $i $j) (and (le (get $range1 "start") (get $range2 "end")) (le (get $range2 "start") (get $range1 "end"))) }}
                {{- fail (printf "Found overlapping priorities under congestion level %s." $congestionLevel) }}
            {{- end }}
        {{- end }}
    {{- end }}
{{- end }}

{{- $deniedRequestActions := dict }}
{{- range $deniedRequestAction := .Values.podProtectionByRateLimiting.deniedRequestActions }}
  {{- $priority := default "all" .priority }}
  {{- $congestionLevel := .congestionLevel }}
  {{- $key := printf "%s|%s" $congestionLevel $priority}}
  {{- if hasKey $deniedRequestActions $key }}
    {{- fail (printf "Found overlapping priorities under congestion level %v." $congestionLevel) }}
  {{- else }}
    {{- $deniedRequestActions = merge $deniedRequestActions (dict $key true) }}
  {{- end }}
{{- end }}
{{- end }}
